"""16x16 tileable block textures for Steel & Crowns."""
from PIL import Image, ImageDraw
import random

OUT = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns/textures/block"
S = 16
random.seed(7)


def canvas():
    return Image.new("RGBA", (S, S), (0, 0, 0, 255))


def speckle(img, base, variants, count):
    for _ in range(count):
        x, y = random.randrange(S), random.randrange(S)
        img.putpixel((x, y), random.choice(variants))


def fill(img, c):
    for y in range(S):
        for x in range(S):
            img.putpixel((x, y), c)


def bloomery():
    img = canvas()
    fill(img, (110, 108, 104, 255))
    speckle(img, None, [(96, 94, 90, 255), (124, 122, 118, 255), (80, 78, 75, 255)], 40)
    # mortar grid (stone-brick style masonry)
    for y in range(0, S, 4):
        for x in range(S):
            img.putpixel((x, y), (70, 68, 65, 255))
    for x in range(0, S, 8):
        for y in range(S):
            img.putpixel((x, y), (70, 68, 65, 255))
    # furnace mouth with ember glow
    d = ImageDraw.Draw(img)
    d.rectangle((5, 9, 10, 14), fill=(20, 18, 17, 255))
    d.rectangle((6, 11, 9, 13), fill=(210, 90, 30, 255))
    d.rectangle((7, 12, 8, 12), fill=(250, 180, 60, 255))
    img.save(f"{OUT}/bloomery.png")


def tanning_vat():
    img = canvas()
    fill(img, (110, 74, 42, 255))
    for x in range(0, S, 3):
        for y in range(S):
            img.putpixel((x, y), (80, 52, 28, 255))
    speckle(img, None, [(130, 90, 52, 255)], 20)
    d = ImageDraw.Draw(img)
    d.rectangle((1, 1, 14, 4), fill=(70, 46, 40, 255))  # liquid at the top
    d.rectangle((1, 1, 14, 1), fill=(50, 32, 28, 255))
    img.save(f"{OUT}/tanning_vat.png")


def castle_wall_stone():
    img = canvas()
    fill(img, (128, 128, 130, 255))
    speckle(img, None, [(140, 140, 143, 255), (110, 110, 113, 255), (95, 95, 98, 255)], 50)
    # large masonry blocks, offset rows like real castle stonework
    rows = [0, 5, 10]
    for ry, y0 in enumerate(rows):
        offset = 0 if ry % 2 == 0 else 4
        for x in range(-4 + offset, S, 8):
            for y in range(y0, min(y0 + 5, S)):
                if x >= 0:
                    img.putpixel((x, y), (85, 85, 88, 255))
    img.save(f"{OUT}/castle_wall_stone.png")


def market_stall():
    img = canvas()
    fill(img, (150, 108, 60, 255))
    for x in range(0, S, 2):
        for y in range(S):
            img.putpixel((x, y), (128, 90, 48, 255))
    d = ImageDraw.Draw(img)
    # striped awning across the top third
    for i, y in enumerate(range(0, 6)):
        color = (150, 30, 30, 255) if (y // 2) % 2 == 0 else (225, 220, 205, 255)
        d.line((0, y, S, y), fill=color)
    img.save(f"{OUT}/market_stall.png")


def throne():
    img = canvas()
    fill(img, (90, 20, 24, 255))  # velvet red base
    speckle(img, None, [(105, 26, 30, 255), (76, 15, 18, 255)], 30)
    d = ImageDraw.Draw(img)
    # gold trim border
    d.rectangle((0, 0, 15, 1), fill=(212, 175, 55, 255))
    d.rectangle((0, 14, 15, 15), fill=(212, 175, 55, 255))
    d.rectangle((0, 0, 1, 15), fill=(212, 175, 55, 255))
    d.rectangle((14, 0, 15, 15), fill=(212, 175, 55, 255))
    d.polygon([(8, 4), (10, 8), (8, 12), (6, 8)], fill=(255, 226, 130, 255))  # emblem
    img.save(f"{OUT}/throne.png")


bloomery()
tanning_vat()
castle_wall_stone()
market_stall()
throne()
print("block textures done")
