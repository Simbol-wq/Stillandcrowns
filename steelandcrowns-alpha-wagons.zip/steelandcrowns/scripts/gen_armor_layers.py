"""
Standard Minecraft humanoid ARMOR layer texture (64x32): layer_1 covers
helmet+chestplate+boots regions, layer_2 covers leggings. This UV layout is
Mojang's public armor-rendering convention, not copyrighted artwork —
filling it in with our own colors/patterns is normal modding practice.
"""
from PIL import Image, ImageDraw

OUT = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns/textures/models/armor"
W, H = 64, 32


def base():
    return Image.new("RGBA", (W, H), (0, 0, 0, 0))


# Head(helmet) regions in layer_1: top(8,0-16,8), sides+front+back (0,8-32,16)
# Body(chest)+legs(boots) regions: (16,16-40,32) body, (0,16-16,32) right leg/boot,
# (40,16-56,32) left arm, (0,16-... ) — using simplified whole-region fills per
# part rather than per-face detail, which is enough for a solid, readable
# in-game silhouette color.
HEAD_TOP = (8, 0, 16, 8)
HEAD_SIDES = (0, 8, 32, 16)
BODY = (16, 16, 40, 32)
RIGHT_LEG = (0, 16, 16, 32)   # also boots region for layer_1
LEFT_ARM_L1 = (40, 16, 56, 32)
RIGHT_ARM_L1 = (40, 16, 56, 32)

LEGGINGS_BODY = (16, 16, 40, 32)   # layer_2 leggings live in the "body" region slot
LEGGINGS_LEG = (0, 16, 16, 32)


def fill_regions(img, regions, color, edge=None):
    d = ImageDraw.Draw(img)
    for (x0, y0, x1, y1) in regions:
        d.rectangle((x0, y0, x1 - 1, y1 - 1), fill=color)
    if edge:
        for (x0, y0, x1, y1) in regions:
            d.rectangle((x0, y0, x1 - 1, y0), fill=edge)


def texture_pattern(img, regions, dot_color, spacing):
    d = ImageDraw.Draw(img)
    for (x0, y0, x1, y1) in regions:
        for x in range(x0, x1, spacing):
            for y in range(y0, y1, spacing):
                d.point((x, y), fill=dot_color)


def padded_layer1():
    img = base()
    color = (188, 166, 122, 255)
    fill_regions(img, [HEAD_TOP, HEAD_SIDES, BODY, RIGHT_LEG, LEFT_ARM_L1], color, (210, 190, 150, 255))
    texture_pattern(img, [BODY, HEAD_SIDES], (150, 128, 90, 255), 3)  # quilting stitches
    img.save(f"{OUT}/padded_layer_1.png")


def padded_layer2():
    img = base()
    color = (170, 148, 106, 255)
    fill_regions(img, [LEGGINGS_BODY, LEGGINGS_LEG], color, (196, 174, 130, 255))
    texture_pattern(img, [LEGGINGS_BODY, LEGGINGS_LEG], (140, 118, 80, 255), 3)
    img.save(f"{OUT}/padded_layer_2.png")


def mail_layer1():
    img = base()
    color = (150, 154, 160, 255)
    fill_regions(img, [HEAD_TOP, HEAD_SIDES, BODY, RIGHT_LEG, LEFT_ARM_L1], color, (185, 189, 195, 255))
    texture_pattern(img, [BODY, HEAD_SIDES, RIGHT_LEG, LEFT_ARM_L1], (95, 99, 105, 255), 2)  # ring pattern
    img.save(f"{OUT}/mail_layer_1.png")


def mail_layer2():
    img = base()
    color = (140, 144, 150, 255)
    fill_regions(img, [LEGGINGS_BODY, LEGGINGS_LEG], color, (175, 179, 185, 255))
    texture_pattern(img, [LEGGINGS_BODY, LEGGINGS_LEG], (90, 94, 100, 255), 2)
    img.save(f"{OUT}/mail_layer_2.png")


def plate_layer1():
    img = base()
    color = (196, 199, 204, 255)
    fill_regions(img, [HEAD_TOP, HEAD_SIDES, BODY, RIGHT_LEG, LEFT_ARM_L1], color, (235, 238, 240, 255))
    d = ImageDraw.Draw(img)
    # rivet highlights + panel shading lines for a plate look
    for (x0, y0, x1, y1) in [BODY, HEAD_SIDES]:
        d.rectangle((x0, y0, x1 - 1, y0), fill=(240, 242, 245, 255))
        d.rectangle((x0, y1 - 2, x1 - 1, y1 - 1), fill=(120, 123, 128, 255))
    img.save(f"{OUT}/plate_layer_1.png")


def plate_layer2():
    img = base()
    color = (182, 185, 190, 255)
    fill_regions(img, [LEGGINGS_BODY, LEGGINGS_LEG], color, (220, 223, 226, 255))
    img.save(f"{OUT}/plate_layer_2.png")


padded_layer1(); padded_layer2()
mail_layer1(); mail_layer2()
plate_layer1(); plate_layer2()
print("armor layer textures done")
