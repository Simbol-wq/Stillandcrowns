"""
Texture sheet for WagonModel.java. Regions below match each addBox's
texOffs + auto box-UV footprint (width = 2*depth + 2*width, height =
depth + height) exactly as declared in the Java model, so recoloring here
never needs a Java change unless the model's box sizes change too.
"""
from PIL import Image, ImageDraw
import random

OUT = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns/textures/entity"
random.seed(3)

img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

HORSE_HI = (120, 80, 50, 255)
HORSE_MID = (92, 60, 38, 255)
HORSE_LO = (60, 38, 24, 255)
MANE = (35, 24, 16, 255)

WOOD_HI = (170, 120, 75, 255)
WOOD_MID = (132, 90, 52, 255)
WOOD_LO = (90, 60, 34, 255)

IRON = (70, 70, 74, 255)
IRON_HI = (110, 110, 116, 255)


def region(x0, y0, x1, y1, base):
    d.rectangle((x0, y0, x1 - 1, y1 - 1), fill=base)


def grain(x0, y0, x1, y1, color, step=3):
    for x in range(x0, x1, step):
        d.line((x, y0, x, y1 - 1), fill=color)


def speckle(x0, y0, x1, y1, colors, count):
    for _ in range(count):
        x = random.randrange(x0, x1)
        y = random.randrange(y0, y1)
        img.putpixel((x, y), random.choice(colors))


# body (horse trunk) 0,0 - 32,16
region(0, 0, 32, 16, HORSE_MID)
speckle(0, 0, 32, 16, [HORSE_HI, HORSE_LO], 60)
d.rectangle((0, 0, 31, 1), fill=HORSE_LO)  # back shading strip

# head+neck 0,16 - 18,25
region(0, 16, 18, 25, HORSE_MID)
speckle(0, 16, 18, 25, [HORSE_HI, HORSE_LO], 20)
d.rectangle((0, 16, 17, 17), fill=MANE)  # mane strip along the top

# legs 32,0 - 40,10 (reused x4)
region(32, 0, 40, 10, HORSE_LO)
d.rectangle((32, 7, 39, 9), fill=(30, 20, 14, 255))  # hoof

# cart bed floor 0,26 - 40,38
region(0, 26, 40, 38, WOOD_MID)
grain(0, 26, 40, 38, WOOD_LO, step=3)
d.rectangle((0, 26, 39, 26), fill=WOOD_HI)

# side walls 40,10 - 62,23
region(40, 10, 62, 23, WOOD_MID)
grain(40, 10, 62, 23, WOOD_LO, step=4)

# front/back walls 0,38 - 22,42
region(0, 38, 22, 42, WOOD_MID)
grain(0, 38, 22, 42, WOOD_LO, step=4)

# wheels 22,38 - 36,50
region(22, 38, 36, 50, WOOD_LO)
d.ellipse((23, 39, 35, 49), outline=IRON_HI, fill=WOOD_MID, width=1)
d.line((29, 39, 29, 49), fill=IRON)  # spoke
d.line((22, 44, 36, 44), fill=IRON)  # spoke

img.save(f"{OUT}/wagon.png")
print("wagon texture done")
