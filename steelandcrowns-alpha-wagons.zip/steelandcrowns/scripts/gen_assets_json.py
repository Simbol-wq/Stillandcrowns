import json
import os

BASE = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns"
MOD = "steelandcrowns"

ITEM_ICONS = [
    ("longsword", "item/handheld"),
    ("halberd", "item/handheld"),
    ("spear", "item/handheld"),
    ("mace", "item/handheld"),
    ("heavy_crossbow", "item/generated"),
    ("kite_shield", "item/generated"),
    ("buckler", "item/generated"),
    ("padded_chestplate", "item/generated"),
    ("chainmail_hauberk", "item/generated"),
    ("plate_cuirass", "item/generated"),
    ("visored_helmet", "item/generated"),
    ("steel_ingot", "item/generated"),
    ("tanned_leather", "item/generated"),
    ("royal_charter", "item/generated"),
]

BLOCKS = ["bloomery", "tanning_vat", "castle_wall_stone", "market_stall", "throne"]

NAMES_EN = {
    "longsword": "Longsword", "halberd": "Halberd", "spear": "Spear", "mace": "Mace",
    "heavy_crossbow": "Heavy Crossbow", "kite_shield": "Kite Shield", "buckler": "Buckler",
    "padded_chestplate": "Padded Chestplate", "chainmail_hauberk": "Chainmail Hauberk",
    "plate_cuirass": "Plate Cuirass", "visored_helmet": "Visored Helmet",
    "steel_ingot": "Steel Ingot", "tanned_leather": "Tanned Leather", "royal_charter": "Royal Charter",
    "bloomery": "Bloomery", "tanning_vat": "Tanning Vat", "castle_wall_stone": "Castle Wall",
    "market_stall": "Market Stall", "throne": "Throne",
    "itemGroup.steelandcrowns.medieval": "Steel & Crowns",
    "entity.steelandcrowns.knight": "Knight", "entity.steelandcrowns.guard": "Guard",
    "entity.steelandcrowns.peasant": "Peasant", "entity.steelandcrowns.king": "King",
    "entity.steelandcrowns.wagon": "Wagon", "entity.steelandcrowns.trebuchet": "Trebuchet",
    "entity.steelandcrowns.battering_ram": "Battering Ram",
}

NAMES_RU = {
    "longsword": "Длинный меч", "halberd": "Алебарда", "spear": "Копьё", "mace": "Булава",
    "heavy_crossbow": "Тяжёлый арбалет", "kite_shield": "Каплевидный щит", "buckler": "Баклер",
    "padded_chestplate": "Стёганый доспех", "chainmail_hauberk": "Кольчужный хауберк",
    "plate_cuirass": "Латный нагрудник", "visored_helmet": "Шлем с забралом",
    "steel_ingot": "Стальной слиток", "tanned_leather": "Дублёная кожа", "royal_charter": "Королевская грамота",
    "bloomery": "Сыродутный горн", "tanning_vat": "Дубильный чан", "castle_wall_stone": "Крепостная стена",
    "market_stall": "Рыночный прилавок", "throne": "Трон",
    "itemGroup.steelandcrowns.medieval": "Сталь и Короны",
    "entity.steelandcrowns.knight": "Рыцарь", "entity.steelandcrowns.guard": "Стражник",
    "entity.steelandcrowns.peasant": "Крестьянин", "entity.steelandcrowns.king": "Король",
    "entity.steelandcrowns.wagon": "Повозка", "entity.steelandcrowns.trebuchet": "Требушет",
    "entity.steelandcrowns.battering_ram": "Таран",
}


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


# item models
for name, parent in ITEM_ICONS:
    write_json(f"{BASE}/models/item/{name}.json",
               {"parent": parent, "textures": {"layer0": f"{MOD}:item/{name}"}})

# block models + blockstates + item-as-block models
for name in BLOCKS:
    write_json(f"{BASE}/models/block/{name}.json",
               {"parent": "block/cube_all", "textures": {"all": f"{MOD}:block/{name}"}})
    write_json(f"{BASE}/blockstates/{name}.json",
               {"variants": {"": {"model": f"{MOD}:block/{name}"}}})
    write_json(f"{BASE}/models/item/{name}.json",
               {"parent": f"{MOD}:block/{name}"})

# lang files
lang_en = {f"item.{MOD}.{n}": NAMES_EN[n] for n, _ in ITEM_ICONS}
lang_en.update({f"block.{MOD}.{n}": NAMES_EN[n] for n in BLOCKS})
lang_en.update({k: v for k, v in NAMES_EN.items() if k.startswith("itemGroup") or k.startswith("entity")})
write_json(f"{BASE}/lang/en_us.json", lang_en)

lang_ru = {f"item.{MOD}.{n}": NAMES_RU[n] for n, _ in ITEM_ICONS}
lang_ru.update({f"block.{MOD}.{n}": NAMES_RU[n] for n in BLOCKS})
lang_ru.update({k: v for k, v in NAMES_RU.items() if k.startswith("itemGroup") or k.startswith("entity")})
write_json(f"{BASE}/lang/ru_ru.json", lang_ru)

print("asset jsons done")
