"""
64x64 humanoid skins using Minecraft's standard (Mojang-documented, not
copyrighted) skin UV layout, rendered with the vanilla PLAYER model layer
in-game (see SoldierRenderer.java) — so we only need to paint pixels here,
no custom body geometry required for these four NPCs.
"""
from PIL import Image, ImageDraw

OUT = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns/textures/entity"
S = 64

HEAD = dict(top=(8, 0, 16, 8), bottom=(16, 0, 24, 8), right=(0, 8, 8, 16),
            front=(8, 8, 16, 16), left=(16, 8, 24, 16), back=(24, 8, 32, 16))
BODY = dict(top=(20, 16, 28, 20), bottom=(28, 16, 36, 20), right=(16, 20, 20, 32),
            front=(20, 20, 28, 32), left=(28, 20, 32, 32), back=(32, 20, 40, 32))
R_ARM = dict(top=(44, 16, 48, 20), bottom=(48, 16, 52, 20), right=(40, 20, 44, 32),
             front=(44, 20, 48, 32), left=(48, 20, 52, 32), back=(52, 20, 56, 32))
L_ARM = dict(top=(36, 48, 40, 52), bottom=(40, 48, 44, 52), right=(32, 52, 36, 64),
             front=(36, 52, 40, 64), left=(40, 52, 44, 64), back=(44, 52, 48, 64))
R_LEG = dict(top=(4, 16, 8, 20), bottom=(8, 16, 12, 20), right=(0, 20, 4, 32),
             front=(4, 20, 8, 32), left=(8, 20, 12, 32), back=(12, 20, 16, 32))
L_LEG = dict(top=(20, 48, 24, 52), bottom=(24, 48, 28, 52), right=(16, 52, 20, 64),
             front=(20, 52, 24, 64), left=(24, 52, 28, 64), back=(28, 52, 32, 64))

SHADE = {"front": 1.0, "right": 0.85, "left": 0.85, "back": 0.7, "top": 1.1, "bottom": 0.6}


def shade(color, factor):
    r, g, b, a = color
    return (min(255, int(r * factor)), min(255, int(g * factor)), min(255, int(b * factor)), a)


def fill_part(img, part_regions, base_color):
    d = ImageDraw.Draw(img)
    for face, (x0, y0, x1, y1) in part_regions.items():
        d.rectangle((x0, y0, x1 - 1, y1 - 1), fill=shade(base_color, SHADE[face]))


def base_skin(skin_tone, tunic_color, legs_color, boots_color):
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    fill_part(img, HEAD, skin_tone)
    fill_part(img, BODY, tunic_color)
    fill_part(img, R_ARM, skin_tone)
    fill_part(img, L_ARM, skin_tone)
    fill_part(img, R_LEG, legs_color)
    fill_part(img, L_LEG, legs_color)
    d = ImageDraw.Draw(img)
    for part in (R_LEG, L_LEG):
        x0, y0, x1, y1 = part["front"]
        d.rectangle((x0, y1 - 3, x1 - 1, y1 - 1), fill=boots_color)
        x0, y0, x1, y1 = part["right"]
        d.rectangle((x0, y1 - 3, x1 - 1, y1 - 1), fill=boots_color)
        x0, y0, x1, y1 = part["left"]
        d.rectangle((x0, y1 - 3, x1 - 1, y1 - 1), fill=boots_color)
    return img


def add_face(img, eye_color=(40, 30, 25, 255)):
    x0, y0, _, _ = HEAD["front"]
    img.putpixel((x0 + 2, y0 + 3), eye_color)
    img.putpixel((x0 + 5, y0 + 3), eye_color)
    d = ImageDraw.Draw(img)
    d.line((x0 + 2, y0 + 6, x0 + 5, y0 + 6), fill=(120, 70, 60, 255))


def add_hair(img, color):
    x0, y0, x1, _ = HEAD["front"]
    d = ImageDraw.Draw(img)
    d.rectangle((x0, y0, x1 - 1, y0 + 1), fill=color)
    for face in ("left", "right", "back"):
        fx0, fy0, fx1, fy1 = HEAD[face]
        d.rectangle((fx0, fy0, fx1 - 1, fy0 + 1), fill=color)
    tx0, ty0, tx1, ty1 = HEAD["top"]
    d.rectangle((tx0, ty0, tx1 - 1, ty1 - 1), fill=color)


def add_belt(img, color):
    d = ImageDraw.Draw(img)
    for face in ("front", "left", "right", "back"):
        x0, y0, x1, y1 = BODY[face]
        mid = (y0 + y1) // 2
        d.rectangle((x0, mid, x1 - 1, mid + 1), fill=color)


def add_helmet_top(img, color):
    d = ImageDraw.Draw(img)
    for face in ("top", "right", "front", "left", "back"):
        x0, y0, x1, y1 = HEAD[face]
        height = (y1 - y0) if face == "top" else max(2, (y1 - y0) // 2)
        d.rectangle((x0, y0, x1 - 1, y0 + height - 1), fill=color)


peasant = base_skin((222, 184, 148, 255), (120, 88, 52, 255), (150, 130, 96, 255), (90, 65, 40, 255))
add_hair(peasant, (92, 64, 40, 255))
add_face(peasant)
add_belt(peasant, (80, 56, 32, 255))
peasant.save(f"{OUT}/peasant.png")

guard = base_skin((214, 176, 140, 255), (150, 154, 160, 255), (60, 62, 66, 255), (40, 40, 44, 255))
add_face(guard)
add_belt(guard, (110, 90, 40, 255))
add_helmet_top(guard, (120, 122, 128, 255))
guard.save(f"{OUT}/guard.png")

knight_metal = (196, 199, 204, 255)
knight = base_skin(knight_metal, (196, 199, 204, 255), (150, 152, 156, 255), (90, 92, 96, 255))
add_helmet_top(knight, knight_metal)
d = ImageDraw.Draw(knight)
vx0, vy0, vx1, vy1 = HEAD["front"]
d.rectangle((vx0 + 1, vy0 + 4, vx1 - 2, vy0 + 5), fill=(30, 30, 34, 255))
add_belt(knight, (212, 175, 55, 255))
knight.save(f"{OUT}/knight.png")

king = base_skin((222, 184, 148, 255), (100, 30, 110, 255), (80, 24, 90, 255), (40, 30, 20, 255))
add_hair(king, (60, 45, 30, 255))
add_face(king)
add_belt(king, (212, 175, 55, 255))
d = ImageDraw.Draw(king)
for face in ("front", "left", "right", "back"):
    x0, y0, x1, y1 = BODY[face]
    d.rectangle((x0, y0, x1 - 1, y0 + 1), fill=(212, 175, 55, 255))
crown_color = (255, 226, 130, 255)
tx0, ty0, tx1, ty1 = HEAD["top"]
d.rectangle((tx0, ty0, tx1 - 1, ty1 - 1), fill=crown_color)
fx0, fy0, fx1, fy1 = HEAD["front"]
d.rectangle((fx0, fy0, fx1 - 1, fy0 + 1), fill=crown_color)
king.save(f"{OUT}/king.png")

print("npc skins done")
