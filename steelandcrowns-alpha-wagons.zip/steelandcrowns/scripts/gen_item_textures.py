"""
Generates 16x16 item icon textures for Steel & Crowns.
Every shape is drawn deliberately (blade/hilt/crossguard, shield outline,
ingot trapezoid, etc.) rather than randomized, aiming for clean readable
silhouettes at Minecraft's item-icon scale.
"""
from PIL import Image, ImageDraw

OUT = "/home/claude/steelandcrowns/src/main/resources/assets/steelandcrowns/textures/item"
S = 16

# --- palette ---
STEEL_HI = (225, 228, 232, 255)
STEEL_MID = (170, 174, 180, 255)
STEEL_LO = (95, 98, 104, 255)
STEEL_EDGE = (245, 248, 250, 255)

IRON_HI = (216, 210, 200, 255)
IRON_MID = (160, 152, 140, 255)
IRON_LO = (90, 84, 76, 255)

WOOD_HI = (168, 118, 74, 255)
WOOD_MID = (122, 82, 48, 255)
WOOD_LO = (74, 48, 27, 255)

LEATHER_HI = (176, 136, 84, 255)
LEATHER_MID = (140, 101, 58, 255)
LEATHER_LO = (95, 67, 38, 255)

GOLD_HI = (255, 226, 130, 255)
GOLD_MID = (212, 175, 55, 255)
GOLD_LO = (140, 110, 30, 255)

CLOTH_HI = (222, 205, 168, 255)
CLOTH_MID = (188, 166, 122, 255)
CLOTH_LO = (130, 112, 78, 255)

RED = (150, 30, 30, 255)


def canvas():
    return Image.new("RGBA", (S, S), (0, 0, 0, 0))


def px(img, x, y, c):
    if 0 <= x < S and 0 <= y < S:
        img.putpixel((x, y), c)


def line(img, x0, y0, x1, y1, c):
    d = ImageDraw.Draw(img)
    d.line((x0, y0, x1, y1), fill=c, width=1)


def thick_diag_blade(img, tip, base, length, hi, mid, lo):
    """Draws a 2px-wide diagonal blade from tip (top-right-ish) to base,
    with a highlight edge on one side and shadow on the other — the same
    trick vanilla tool icons use to read as 'metal' at 16px."""
    tx, ty = tip
    for i in range(length):
        x = tx - i
        y = ty + i
        px(img, x, y, mid)
        px(img, x - 1, y, hi)
        px(img, x + 1, y, lo)


def sword(name, hi, mid, lo, grip_hi, grip_lo, blade_len=9, guard_w=5):
    img = canvas()
    tip = (13, 1)
    thick_diag_blade(img, tip, None, blade_len, hi, mid, lo)
    # crossguard perpendicular to blade near the grip end
    gx, gy = tip[0] - blade_len + 1, tip[1] + blade_len - 1
    for i in range(-guard_w // 2, guard_w // 2 + 1):
        px(img, gx + i, gy - i, GOLD_MID)
    # grip + pommel continuing the diagonal
    for i in range(1, 4):
        px(img, gx - i, gy + i, grip_mid_or(grip_hi, i))
        px(img, gx - i + 1, gy + i, grip_lo)
    px(img, gx - 4, gy + 4, (40, 40, 45, 255))  # pommel
    img.save(f"{OUT}/{name}.png")


def grip_mid_or(hi, i):
    return hi if i == 1 else (90, 60, 35, 255)


def polearm(name, head_kind, shaft_hi=WOOD_HI, shaft_mid=WOOD_MID, shaft_lo=WOOD_LO,
            head_hi=STEEL_HI, head_mid=STEEL_MID, head_lo=STEEL_LO):
    img = canvas()
    # long diagonal shaft corner-to-corner
    for i in range(14):
        x, y = 13 - i, 1 + i
        px(img, x, y, shaft_mid)
        px(img, x - 1, y, shaft_hi if i % 3 else shaft_lo)
    if head_kind == "halberd_axe":
        # axe blade + spike near the top of the shaft
        for dx, dy in [(-3, -2), (-2, -2), (-1, -1), (0, -1), (-3, -1), (-2, -1), (-4, 0), (-3, 0)]:
            px(img, 13 + dx, 1 + dy, head_mid)
        px(img, 10, -1 + 2, head_hi)
        px(img, 14, 0, head_hi)  # top spike
        px(img, 14, -1, head_hi)
    elif head_kind == "spear":
        for dx, dy in [(0, -2), (1, -1), (-1, -1), (0, -1)]:
            px(img, 13 + dx, 1 + dy, head_hi if dy == -2 else head_mid)
        px(img, 13, -2, head_edge_or(head_hi))
    img.save(f"{OUT}/{name}.png")


def head_edge_or(c):
    return STEEL_EDGE


def mace(name):
    img = canvas()
    # shaft
    for i in range(9):
        x, y = 12 - int(i * 0.4), 4 + i
        px(img, x, y, WOOD_MID)
        px(img, x - 1, y, WOOD_LO)
    # round flanged head near the top
    head_cells = [(11, 1), (12, 1), (13, 1), (10, 2), (11, 2), (12, 2), (13, 2), (14, 2),
                  (10, 3), (11, 3), (12, 3), (13, 3), (14, 3), (11, 4), (12, 4), (13, 4)]
    for (x, y) in head_cells:
        img.putpixel((x, y), STEEL_MID)
    for (x, y) in [(11, 1), (10, 2), (10, 3), (11, 4)]:
        img.putpixel((x, y), STEEL_HI)
    for (x, y) in [(13, 1), (14, 2), (14, 3), (13, 4)]:
        img.putpixel((x, y), STEEL_LO)
    # flange spikes
    for (x, y) in [(9, 2), (15, 2), (12, 0)]:
        img.putpixel((x, y), STEEL_EDGE)
    img.save(f"{OUT}/{name}.png")


def crossbow(name):
    img = canvas()
    d = ImageDraw.Draw(img)
    # bow arms (curved-ish, approximated) horizontally
    d.line((1, 6, 6, 4), fill=WOOD_MID, width=1)
    d.line((6, 4, 6, 9), fill=WOOD_LO, width=1)
    d.line((10, 4, 10, 9), fill=WOOD_LO, width=1)
    d.line((10, 4, 15, 6), fill=WOOD_MID, width=1)
    d.line((1, 6, 15, 6), fill=(210, 210, 215, 255), width=1)  # string
    # stock
    for x in range(6, 12):
        px(img, x, 9, WOOD_MID)
        px(img, x, 10, WOOD_LO)
    for x in range(9, 13):
        px(img, x, 11, WOOD_LO)
    px(img, 8, 8, STEEL_MID)  # trigger mechanism nub
    img.save(f"{OUT}/{name}.png")


def shield(name, kind, rim, wood, boss):
    img = canvas()
    d = ImageDraw.Draw(img)
    if kind == "kite":
        pts = [(4, 2), (11, 2), (11, 8), (7, 14), (4, 8)]
    else:  # buckler, small round
        pts = [(5, 3), (10, 3), (12, 6), (10, 10), (5, 10), (3, 6)]
    d.polygon(pts, fill=wood, outline=rim)
    cx = 7 if kind == "kite" else 7
    cy = 6 if kind == "kite" else 6
    d.ellipse((cx - 1, cy - 1, cx + 1, cy + 1), fill=boss)
    img.save(f"{OUT}/{name}.png")


def steel_ingot(name):
    img = canvas()
    d = ImageDraw.Draw(img)
    d.polygon([(3, 10), (5, 7), (11, 7), (13, 10), (11, 12), (5, 12)], fill=STEEL_MID)
    d.line((3, 10, 5, 7), fill=STEEL_HI)
    d.line((5, 7, 11, 7), fill=STEEL_HI)
    d.line((11, 7, 13, 10), fill=STEEL_LO)
    d.line((13, 10, 11, 12), fill=STEEL_LO)
    d.line((5, 12, 3, 10), fill=STEEL_LO)
    img.save(f"{OUT}/{name}.png")


def tanned_leather(name):
    img = canvas()
    d = ImageDraw.Draw(img)
    d.polygon([(3, 4), (9, 3), (13, 6), (12, 11), (6, 13), (2, 9)], fill=LEATHER_MID)
    d.line((3, 4, 9, 3), fill=LEATHER_HI)
    d.line((2, 9, 6, 13), fill=LEATHER_LO)
    # stitch marks
    for (x, y) in [(5, 6), (7, 7), (9, 8), (6, 10)]:
        img.putpixel((x, y), LEATHER_LO)
    img.save(f"{OUT}/{name}.png")


def royal_charter(name):
    img = canvas()
    d = ImageDraw.Draw(img)
    d.rectangle((3, 2, 12, 13), fill=(232, 220, 190, 255))
    d.rectangle((3, 2, 12, 3), fill=CLOTH_LO)
    d.rectangle((3, 12, 12, 13), fill=CLOTH_LO)
    for y in (5, 7, 9):
        d.line((5, y, 10, y), fill=(120, 100, 70, 255))
    d.ellipse((8, 9, 12, 13), fill=RED)  # wax seal
    img.putpixel((10, 11), GOLD_MID)
    img.save(f"{OUT}/{name}.png")


def armor_piece(name, kind, base_hi, base_mid, base_lo):
    """Generic humanoid-armor-shaped icon: shoulders + chest OR dome helmet."""
    img = canvas()
    d = ImageDraw.Draw(img)
    if kind == "chest":
        d.polygon([(4, 3), (12, 3), (13, 6), (12, 13), (4, 13), (3, 6)], fill=base_mid)
        d.rectangle((3, 3, 5, 5), fill=base_hi)   # left shoulder pad
        d.rectangle((11, 3, 13, 5), fill=base_hi)  # right shoulder pad
        d.line((4, 13, 12, 13), fill=base_lo)
        d.line((4, 3, 3, 6), fill=base_lo)
    elif kind == "helmet":
        d.pieslice((3, 2, 13, 12), 180, 360, fill=base_mid)
        d.rectangle((3, 7, 13, 10), fill=base_mid)
        d.line((3, 7, 13, 7), fill=base_hi)
        d.rectangle((5, 8, 11, 9), fill=(30, 30, 34, 255))  # visor slit
        d.line((3, 10, 13, 10), fill=base_lo)
    img.save(f"{OUT}/{name}.png")


sword("longsword", STEEL_HI, STEEL_MID, STEEL_LO, WOOD_HI, WOOD_LO, blade_len=10, guard_w=5)
polearm("halberd", "halberd_axe")
polearm("spear", "spear", head_hi=IRON_HI, head_mid=IRON_MID, head_lo=IRON_LO)
mace("mace")
crossbow("heavy_crossbow")
shield("kite_shield", "kite", (60, 40, 20, 255), WOOD_MID, GOLD_MID)
shield("buckler", "buckler", (70, 70, 75, 255), STEEL_MID, GOLD_MID)
steel_ingot("steel_ingot")
tanned_leather("tanned_leather")
royal_charter("royal_charter")
armor_piece("padded_chestplate", "chest", CLOTH_HI, CLOTH_MID, CLOTH_LO)
armor_piece("chainmail_hauberk", "chest", (200, 205, 210, 255), (140, 145, 152, 255), (80, 84, 90, 255))
armor_piece("plate_cuirass", "chest", STEEL_HI, STEEL_MID, STEEL_LO)
armor_piece("visored_helmet", "helmet", STEEL_HI, STEEL_MID, STEEL_LO)

print("item textures done")
