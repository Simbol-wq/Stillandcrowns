package com.steelandcrowns.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Bloomery — the first stage of the medieval smithing chain
 * (ore + charcoal -> bloom -> hammered into steel ingot at the anvil).
 * A full implementation adds a BlockEntity with a smelting process
 * similar to a furnace but multi-stage (bloom -> billet -> ingot),
 * gated behind a minimum structure size check for balance.
 */
public class BloomeryBlock extends Block {
    public BloomeryBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
