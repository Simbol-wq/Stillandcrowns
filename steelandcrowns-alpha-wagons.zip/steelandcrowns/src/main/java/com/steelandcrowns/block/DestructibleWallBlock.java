package com.steelandcrowns.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Castle/fortification wall with its own hit-point pool, separate from
 * vanilla hardness/blast-resistance. Siege engine projectiles apply damage
 * to a tracked HP value (via BlockEntity or a lightweight capability map
 * keyed by BlockPos) instead of instantly breaking or being fully immune —
 * this lets walls crumble progressively across a siege.
 */
public class DestructibleWallBlock extends Block {

    private final int maxHitPoints;

    public DestructibleWallBlock(int maxHitPoints, BlockBehaviour.Properties properties) {
        super(properties);
        this.maxHitPoints = maxHitPoints;
    }

    public int getMaxHitPoints() {
        return maxHitPoints;
    }

    // TODO: attach a BlockEntity (or capability-backed side table) tracking
    // current HP per placed wall block, decremented by siege projectile
    // impact events, with a crumble/rubble state swap at low HP thresholds.
}
