package com.steelandcrowns.worldgen;

import net.minecraft.server.level.ServerLevel;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RoadNetworkManager isn't SavedData in this skeleton (its state is
 * re-derivable/cheap to recompute), so it's kept in a simple in-memory
 * map keyed by level. A production version should persist edges +
 * development so roads don't reset on server restart.
 */
public final class RoadWorldRegistry {

    private static final Map<ServerLevel, RoadNetworkManager> MANAGERS = new ConcurrentHashMap<>();

    public static RoadNetworkManager get(ServerLevel level) {
        return MANAGERS.computeIfAbsent(level, l -> new RoadNetworkManager());
    }

    private RoadWorldRegistry() {}
}
