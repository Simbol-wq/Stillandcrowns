package com.steelandcrowns.worldgen.structures;

/**
 * Registration point for the castle jigsaw structure set. A full
 * implementation supplies:
 *  - datagen-produced template pools under
 *    data/steelandcrowns/worldgen/template_pool/castle/*.json referencing
 *    NBT structure pieces (built in-game with structure blocks),
 *  - a JigsawStructure/Structure JSON at
 *    data/steelandcrowns/worldgen/structure/castle.json with terrain
 *    adaptation set to BEARD_THIN or BEARD_BOX so pieces blend into slopes,
 *    plus a StructurePlacement (RandomSpreadStructurePlacement) tuned for
 *    rarity comparable to vanilla mansions,
 *  - a call into RoadNetworkManager.registerSettlement(...) from a
 *    structure-generation or first-chunk-load event so every castle joins
 *    the shared road graph, and
 *  - a matching Faction capital/settlement registration so the structure
 *    is claimed by (or spawns) a faction on generation.
 * Kept as a documentation stub here since jigsaw structures are primarily
 * defined via datagen JSON rather than Java code.
 */
public final class CastleStructure {
    public static final String STRUCTURE_SET_ID = "steelandcrowns:castle";
    private CastleStructure() {}
}
