package com.steelandcrowns.worldgen;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Progressive road development. Every stage uses vanilla blocks on purpose —
 * roads need no custom textures at all. A road starts as a bare trampled
 * trail and is upgraded in place as its `development` value rises.
 */
public enum RoadStage {

    /** Just walked-over dirt — thin, patchy, occasional grass poking through. */
    TRAIL(0, Blocks.DIRT_PATH.defaultBlockState()),

    /** A well-used route: coarse dirt with dirt-path core, wider footprint. */
    BEATEN_PATH(30, Blocks.DIRT_PATH.defaultBlockState()),

    /** Faction has invested in it: gravel surface, more durable, less erosion. */
    GRAVEL(60, Blocks.GRAVEL.defaultBlockState()),

    /** Fully paved royal road: stone brick / cobblestone path connecting capitals. */
    PAVED(90, Blocks.STONE_BRICKS.defaultBlockState());

    public final int minDevelopment;
    private final BlockState surface;

    RoadStage(int minDevelopment, BlockState surface) {
        this.minDevelopment = minDevelopment;
        this.surface = surface;
    }

    public BlockState surfaceState() {
        return surface;
    }

    /** Width in blocks either side of the centerline that gets paved at this stage. */
    public int widthRadius() {
        return switch (this) {
            case TRAIL -> 0;          // single-block-wide footpath
            case BEATEN_PATH -> 0;    // still single-wide, just denser/longer-lived
            case GRAVEL -> 1;         // 3 blocks wide
            case PAVED -> 1;          // 3 blocks wide, could add borders later
        };
    }

    public static RoadStage forDevelopment(float development) {
        RoadStage result = TRAIL;
        for (RoadStage stage : values()) {
            if (development >= stage.minDevelopment) {
                result = stage;
            }
        }
        return result;
    }
}
