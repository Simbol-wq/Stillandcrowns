package com.steelandcrowns.worldgen.settlement;

/**
 * A category of building the layout generator can place. `minSize`/`maxSize`
 * are footprint side lengths in blocks (square-ish plots); the generator
 * picks a random size in range per instance so even two houses of the same
 * type rarely look identical, and combines that with a random NBT variant
 * id + rotation (see {@link SettlementLayoutGenerator}) for further variety.
 */
public enum BuildingType {

    HOUSE(60, 5, 8),          // common — most of the town's footprint
    MARKET_STALL(15, 3, 5),   // small, clusters near the town square
    TAVERN(6, 7, 10),
    SMITHY(6, 6, 9),
    STORAGE(6, 4, 6),
    WELL(4, 2, 2),            // town-square landmark, fixed small size
    CHURCH_SHRINE(2, 8, 12),  // rare, larger
    THRONE_HALL(1, 12, 18);   // capital-only, handled separately by tier check

    public final int weight;
    public final int minSize;
    public final int maxSize;

    BuildingType(int weight, int minSize, int maxSize) {
        this.weight = weight;
        this.minSize = minSize;
        this.maxSize = maxSize;
    }
}
