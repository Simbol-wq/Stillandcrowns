package com.steelandcrowns.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.*;

/**
 * Coarse terrain-aware A* between two settlement anchors. Operates on a grid
 * sampled every {@link #STEP} blocks (not per-block) — the result is a list
 * of {@link RoadWaypoint}s, later densified/smoothed and placed by
 * {@link RoadNetworkManager} / {@link BridgeBuilder}.
 *
 * Cost model per step: base distance + elevation-change penalty (discourages
 * stairs/cliffs) + a water-crossing penalty proportional to depth. Shallow
 * water (streams, riverbanks) is cheap to cross; deep water beyond
 * {@link #MAX_BRIDGEABLE_DEPTH} is treated as impassable so roads don't try
 * to bridge entire oceans — they'll route around instead.
 */
public class RoadPathfinder {

    private static final int STEP = 4; // blocks per grid cell
    private static final int MAX_NODES = 20_000; // safety cap
    private static final int MAX_BRIDGEABLE_DEPTH = 12; // blocks of water depth

    public record RoadWaypoint(BlockPos pos, boolean bridge) {}

    private record Node(int gx, int gz) {}

    public List<RoadWaypoint> findPath(ServerLevel level, BlockPos start, BlockPos end) {
        Node startNode = toGrid(start);
        Node endNode = toGrid(end);

        Map<Node, Node> cameFrom = new HashMap<>();
        Map<Node, Double> gScore = new HashMap<>();
        PriorityQueue<Node> open = new PriorityQueue<>(
                Comparator.comparingDouble(n -> gScore.getOrDefault(n, Double.MAX_VALUE) + heuristic(n, endNode)));

        gScore.put(startNode, 0.0);
        open.add(startNode);

        int visited = 0;
        while (!open.isEmpty() && visited++ < MAX_NODES) {
            Node current = open.poll();
            if (current.equals(endNode)) {
                return reconstruct(cameFrom, current, level);
            }
            for (Node neighbor : neighbors(current)) {
                double stepCost = costBetween(level, current, neighbor);
                if (stepCost == Double.POSITIVE_INFINITY) continue; // too deep to bridge

                double tentativeG = gScore.getOrDefault(current, Double.MAX_VALUE) + stepCost;
                if (tentativeG < gScore.getOrDefault(neighbor, Double.MAX_VALUE)) {
                    cameFrom.put(neighbor, current);
                    gScore.put(neighbor, tentativeG);
                    open.add(neighbor);
                }
            }
        }
        return straightLineFallback(level, start, end);
    }

    private double heuristic(Node a, Node b) {
        return Math.hypot(a.gx() - b.gx(), a.gz() - b.gz()) * STEP;
    }

    private List<Node> neighbors(Node n) {
        List<Node> result = new ArrayList<>(8);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                result.add(new Node(n.gx() + dx, n.gz() + dz));
            }
        }
        return result;
    }

    private double costBetween(ServerLevel level, Node from, Node to) {
        int fromY = surfaceHeight(level, from);
        int toY = surfaceHeight(level, to);
        int waterDepth = waterDepth(level, to);

        if (waterDepth > MAX_BRIDGEABLE_DEPTH) return Double.POSITIVE_INFINITY; // deep ocean/lake: go around

        double horizontal = (from.gx() != to.gx() && from.gz() != to.gz()) ? Math.sqrt(2) * STEP : STEP;
        double elevationPenalty = Math.abs(toY - fromY) * 2.5;
        double bridgePenalty = waterDepth * 4.0; // bridging costs more than dry land, scales with depth
        return horizontal + elevationPenalty + bridgePenalty;
    }

    private int surfaceHeight(ServerLevel level, Node n) {
        BlockPos pos = toBlockPos(n);
        return level.getHeight(Heightmap.Types.WORLD_SURFACE, pos.getX(), pos.getZ());
    }

    /** Returns 0 for dry land, otherwise the depth of the water column at this node. */
    private int waterDepth(ServerLevel level, Node n) {
        BlockPos pos = toBlockPos(n);
        int floorY = level.getHeight(Heightmap.Types.OCEAN_FLOOR, pos.getX(), pos.getZ());
        int surfaceY = level.getHeight(Heightmap.Types.WORLD_SURFACE, pos.getX(), pos.getZ());
        return Math.max(0, (surfaceY - floorY) - 1);
    }

    private List<RoadWaypoint> reconstruct(Map<Node, Node> cameFrom, Node current, ServerLevel level) {
        List<RoadWaypoint> path = new ArrayList<>();
        path.add(toWaypoint(current, level));
        while (cameFrom.containsKey(current)) {
            current = cameFrom.get(current);
            path.add(toWaypoint(current, level));
        }
        Collections.reverse(path);
        return path;
    }

    private List<RoadWaypoint> straightLineFallback(ServerLevel level, BlockPos start, BlockPos end) {
        List<RoadWaypoint> path = new ArrayList<>();
        int steps = Math.max(1, (int) (start.distSqr(end) / (STEP * STEP)));
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            int x = (int) Math.round(start.getX() + (end.getX() - start.getX()) * t);
            int z = (int) Math.round(start.getZ() + (end.getZ() - start.getZ()) * t);
            int y = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
            boolean bridge = waterDepth(level, new Node(Math.floorDiv(x, STEP), Math.floorDiv(z, STEP))) > 0;
            path.add(new RoadWaypoint(new BlockPos(x, y, z), bridge));
        }
        return path;
    }

    private Node toGrid(BlockPos pos) {
        return new Node(Math.floorDiv(pos.getX(), STEP), Math.floorDiv(pos.getZ(), STEP));
    }

    private BlockPos toBlockPos(Node n) {
        return new BlockPos(n.gx() * STEP, 0, n.gz() * STEP);
    }

    private RoadWaypoint toWaypoint(Node n, ServerLevel level) {
        int x = n.gx() * STEP;
        int z = n.gz() * STEP;
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
        boolean bridge = waterDepth(level, n) > 0;
        return new RoadWaypoint(new BlockPos(x, y, z), bridge);
    }
}
