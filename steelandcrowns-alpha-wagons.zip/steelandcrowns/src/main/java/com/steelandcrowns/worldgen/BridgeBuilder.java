package com.steelandcrowns.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Builds a simple bridge deck (+ vertical support posts down to the
 * riverbed/ocean floor, + a fence railing) at a single waypoint marked as
 * {@code bridge} by {@link RoadPathfinder}. Deck material follows the same
 * {@link RoadStage} progression as the rest of the road — a fresh path
 * crosses water on plain oak planks, a fully developed royal road crosses
 * it on stone bricks.
 */
public final class BridgeBuilder {

    public void placeBridgeSegment(ServerLevel level, BlockPos center, RoadStage stage) {
        BlockState deck = deckStateFor(stage);
        BlockState railing = Blocks.OAK_FENCE.defaultBlockState();

        int floorY = level.getHeight(Heightmap.Types.OCEAN_FLOOR, center.getX(), center.getZ());
        int waterSurfaceY = level.getHeight(Heightmap.Types.WORLD_SURFACE, center.getX(), center.getZ());
        int deckY = waterSurfaceY + 1;

        // Deck, 3 blocks wide (center + 1 each side across the crossing direction
        // is approximated here as both X and Z — acceptable for short spans;
        // a fuller implementation would orient the railing perpendicular to travel).
        for (int dx = -1; dx <= 1; dx++) {
            BlockPos deckPos = new BlockPos(center.getX() + dx, deckY, center.getZ());
            level.setBlock(deckPos, deck, 3);
        }

        // Railings on either edge of the deck.
        level.setBlock(new BlockPos(center.getX() - 1, deckY + 1, center.getZ()), railing, 3);
        level.setBlock(new BlockPos(center.getX() + 1, deckY + 1, center.getZ()), railing, 3);

        // Support post straight down to the floor, every waypoint (simple but sturdy;
        // could be thinned to every Nth waypoint once spans are validated in-game).
        BlockState post = Blocks.OAK_LOG.defaultBlockState();
        for (int y = deckY - 1; y > floorY; y--) {
            level.setBlock(new BlockPos(center.getX(), y, center.getZ()), post, 3);
        }
    }

    private BlockState deckStateFor(RoadStage stage) {
        return switch (stage) {
            case TRAIL, BEATEN_PATH -> Blocks.OAK_PLANKS.defaultBlockState();
            case GRAVEL -> Blocks.SPRUCE_PLANKS.defaultBlockState();
            case PAVED -> Blocks.STONE_BRICKS.defaultBlockState();
        };
    }
}
