package com.steelandcrowns.worldgen.settlement;

import net.minecraft.core.BlockPos;

import java.util.*;

/**
 * Packs building plots tightly around a settlement anchor with only
 * {@link #ALLEY_WIDTH}-block alleys between them — deliberately cramped
 * ("тесненько"), the way a real medieval town grew inside its walls, rather
 * than vanilla-village-style widely spaced houses on a grid.
 *
 * Algorithm (organic growth, not a fixed grid, so no two towns — or two
 * plots in the same town — line up identically):
 *  1. Start a frontier queue at the settlement center.
 *  2. Pop a candidate anchor, pick a random {@link BuildingType} (weighted)
 *     and a random footprint size within that type's range.
 *  3. If the footprint + a 1-block alley margin doesn't overlap anything
 *     already placed, commit it, and push four new frontier candidates
 *     just past its N/S/E/W edges so growth continues outward from it.
 *  4. Otherwise shrink the footprint once and retry; if it still doesn't
 *     fit, drop this candidate.
 *  5. Stop once the target building count is reached or the radius cap is hit.
 *
 * variantId/rotation on each {@link PlannedBuilding} are randomized
 * independently of position, so even repeated HOUSE plots next to each
 * other get different template + orientation — the actual NBT template
 * pool (a handful of hand-built house variants per type) is a datagen task,
 * this class only decides where things go and which variant slot to ask for.
 */
public class SettlementLayoutGenerator {

    private static final int ALLEY_WIDTH = 1;
    private static final int MAX_FRONTIER_ATTEMPTS = 4000;

    public List<PlannedBuilding> generate(BlockPos center, int radius, int targetBuildingCount,
                                           long seed, boolean isCapital) {
        Random random = new Random(seed);
        List<PlannedBuilding> result = new ArrayList<>();
        Set<Long> occupied = new HashSet<>();
        Deque<int[]> frontier = new ArrayDeque<>();
        frontier.add(new int[]{0, 0});

        boolean throneHallPlaced = !isCapital; // never place one unless it's a capital
        int attempts = 0;

        while (!frontier.isEmpty() && result.size() < targetBuildingCount && attempts++ < MAX_FRONTIER_ATTEMPTS) {
            int[] anchor = frontier.poll();
            if (Math.abs(anchor[0]) > radius || Math.abs(anchor[1]) > radius) continue;

            BuildingType type = pickWeightedType(random, isCapital && !throneHallPlaced && result.size() > targetBuildingCount / 2);
            int size = type.minSize + random.nextInt(Math.max(1, type.maxSize - type.minSize + 1));

            if (!fits(occupied, anchor[0], anchor[1], size)) {
                size = Math.max(type.minSize, size - 2); // shrink once and retry
                if (!fits(occupied, anchor[0], anchor[1], size)) continue; // give up on this spot
            }

            markOccupied(occupied, anchor[0], anchor[1], size);
            int variantId = random.nextInt(4); // assumes ~4 NBT variants per type; adjust once real pools exist
            int rotation = random.nextInt(4) * 90;

            BlockPos origin = center.offset(anchor[0], 0, anchor[1]);
            result.add(new PlannedBuilding(origin, type, size, variantId, rotation));

            if (type == BuildingType.THRONE_HALL) throneHallPlaced = true;

            int step = size + ALLEY_WIDTH;
            frontier.add(new int[]{anchor[0] + step, anchor[1]});
            frontier.add(new int[]{anchor[0] - step, anchor[1]});
            frontier.add(new int[]{anchor[0], anchor[1] + step});
            frontier.add(new int[]{anchor[0], anchor[1] - step});
        }

        return result;
    }

    private BuildingType pickWeightedType(Random random, boolean forceThroneHall) {
        if (forceThroneHall) return BuildingType.THRONE_HALL;

        BuildingType[] candidates = Arrays.stream(BuildingType.values())
                .filter(t -> t != BuildingType.THRONE_HALL)
                .toArray(BuildingType[]::new);
        int totalWeight = Arrays.stream(candidates).mapToInt(t -> t.weight).sum();
        int roll = random.nextInt(totalWeight);
        int cumulative = 0;
        for (BuildingType type : candidates) {
            cumulative += type.weight;
            if (roll < cumulative) return type;
        }
        return BuildingType.HOUSE;
    }

    private boolean fits(Set<Long> occupied, int x, int z, int size) {
        for (int dx = -ALLEY_WIDTH; dx < size + ALLEY_WIDTH; dx++) {
            for (int dz = -ALLEY_WIDTH; dz < size + ALLEY_WIDTH; dz++) {
                if (occupied.contains(pack(x + dx, z + dz))) return false;
            }
        }
        return true;
    }

    private void markOccupied(Set<Long> occupied, int x, int z, int size) {
        for (int dx = 0; dx < size; dx++) {
            for (int dz = 0; dz < size; dz++) {
                occupied.add(pack(x + dx, z + dz));
            }
        }
    }

    private long pack(int x, int z) {
        return (((long) x) << 32) ^ (z & 0xffffffffL);
    }
}
