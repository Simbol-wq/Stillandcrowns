package com.steelandcrowns.worldgen.settlement;

import net.minecraft.core.BlockPos;

/**
 * One placed plot in a generated settlement, ready to be handed to a
 * structure/template placer. `variantId` and `rotation` exist specifically
 * to avoid the "copy-paste" look: even with only 3-4 NBT templates per
 * {@link BuildingType}, randomizing which one is used plus a 0/90/180/270
 * rotation gives a visibly different result at every plot.
 */
public record PlannedBuilding(BlockPos origin, BuildingType type, int footprintSize,
                               int variantId, int rotationDegrees) {
}
