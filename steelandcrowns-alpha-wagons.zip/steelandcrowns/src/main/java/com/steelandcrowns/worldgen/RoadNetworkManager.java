package com.steelandcrowns.worldgen;

import com.steelandcrowns.worldgen.RoadPathfinder.RoadWaypoint;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Owns the settlement graph, the (lazily computed) paths between nodes, and
 * their development stage.
 *
 *  1. Pathing — computed once per edge via {@link RoadPathfinder}, cached as
 *     a waypoint list (each tagged bridge/no-bridge).
 *  2. Paving — a road's blocks are only ever placed for waypoints inside a
 *     currently-loaded chunk (see {@link com.steelandcrowns.events.RoadChunkPaver}),
 *     and re-painted whenever the edge's development stage advances, so a
 *     trail you walked past early game later shows up upgraded without ever
 *     touching unloaded terrain. Bridge waypoints are routed to
 *     {@link BridgeBuilder} instead of the flat-surface placer.
 */
public class RoadNetworkManager {

    public record RoadNode(BlockPos anchor, String settlementId) {}

    public static class RoadEdge {
        public final RoadNode from;
        public final RoadNode to;
        public final List<RoadWaypoint> waypoints;
        /** 0-100, drives {@link RoadStage#forDevelopment}. */
        public float development = 0f;

        RoadEdge(RoadNode from, RoadNode to, List<RoadWaypoint> waypoints) {
            this.from = from;
            this.to = to;
            this.waypoints = waypoints;
        }

        public RoadStage stage() {
            return RoadStage.forDevelopment(development);
        }
    }

    private final List<RoadNode> nodes = new ArrayList<>();
    private final List<RoadEdge> edges = new ArrayList<>();
    private final RoadPathfinder pathfinder = new RoadPathfinder();
    private final BridgeBuilder bridgeBuilder = new BridgeBuilder();
    /** Tracks the last stage painted per waypoint-per-edge so we don't re-pave every chunk load. */
    private final Map<String, RoadStage> paintedStageByWaypoint = new HashMap<>();

    public void registerSettlement(ServerLevel level, BlockPos anchor, String settlementId) {
        RoadNode node = new RoadNode(anchor, settlementId);
        nodes.add(node);
        connectToNearestNodes(level, node, 2);
    }

    private void connectToNearestNodes(ServerLevel level, RoadNode newNode, int maxConnections) {
        nodes.stream()
                .filter(n -> n != newNode)
                .sorted((a, b) -> Double.compare(
                        a.anchor().distSqr(newNode.anchor()), b.anchor().distSqr(newNode.anchor())))
                .limit(maxConnections)
                .forEach(nearby -> {
                    List<RoadWaypoint> path = pathfinder.findPath(level, newNode.anchor(), nearby.anchor());
                    edges.add(new RoadEdge(newNode, nearby, path));
                });
    }

    /** Called every simulation interval to grow roads over time (hook to faction wealth/trade for nuance). */
    public void advanceDevelopment(float amount) {
        for (RoadEdge edge : edges) {
            if (edge.development < 100f) {
                edge.development = Math.min(100f, edge.development + amount);
            }
        }
    }

    /**
     * Paves whichever waypoints of whichever edges fall inside this chunk.
     * Safe to call every time a chunk loads — no-ops for waypoints already
     * painted at the current stage.
     */
    public void paveChunk(ServerLevel level, ChunkPos chunkPos) {
        for (RoadEdge edge : edges) {
            RoadStage stage = edge.stage();
            String edgeId = edge.from.settlementId() + "->" + edge.to.settlementId();

            for (RoadWaypoint waypoint : edge.waypoints) {
                if (!new ChunkPos(waypoint.pos()).equals(chunkPos)) continue;

                String key = edgeId + "@" + waypoint.pos();
                if (paintedStageByWaypoint.get(key) == stage) continue;

                if (waypoint.bridge()) {
                    bridgeBuilder.placeBridgeSegment(level, waypoint.pos(), stage);
                } else {
                    placeRoadSegment(level, waypoint.pos(), stage);
                }
                paintedStageByWaypoint.put(key, stage);
            }
        }
    }

    private void placeRoadSegment(ServerLevel level, BlockPos center, RoadStage stage) {
        BlockState surface = stage.surfaceState();
        int radius = stage.widthRadius();
        int surfaceY = level.getHeight(Heightmap.Types.WORLD_SURFACE, center.getX(), center.getZ());
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                BlockPos pos = new BlockPos(center.getX() + dx, surfaceY - 1, center.getZ() + dz);
                level.setBlock(pos, surface, 3);
            }
        }
    }

    public List<RoadEdge> getEdges() {
        return edges;
    }

    public List<RoadNode> getNodes() {
        return nodes;
    }
}
