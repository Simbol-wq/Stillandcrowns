package com.steelandcrowns.economy;

import java.util.EnumMap;
import java.util.Map;
import java.util.Random;

/**
 * What a single settlement actually has and needs. Real numbers, not
 * flavor: {@link com.steelandcrowns.simulation.WagonSpawner} reads this to
 * decide what cargo is worth hauling, and {@link TownEconomyManager} applies
 * the transfer when a wagon actually arrives.
 */
public class TownLedger {

    public enum Good { GRAIN, ORE, TIMBER, CLOTH }

    private final Map<Good, Integer> stock = new EnumMap<>(Good.class);

    public TownLedger(Random random) {
        for (Good good : Good.values()) {
            stock.put(good, 20 + random.nextInt(60)); // every town starts with some baseline stock
        }
    }

    public int get(Good good) {
        return stock.getOrDefault(good, 0);
    }

    public void add(Good good, int amount) {
        stock.merge(good, amount, Integer::sum);
    }

    public boolean remove(Good good, int amount) {
        int current = get(good);
        if (current < amount) return false;
        stock.put(good, current - amount);
        return true;
    }

    /** A good is worth exporting once a town is sitting on a comfortable surplus of it. */
    public boolean hasSurplus(Good good, int threshold) {
        return get(good) >= threshold;
    }
}
