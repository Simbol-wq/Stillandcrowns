package com.steelandcrowns.economy;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * One {@link TownLedger} per registered settlement. Kept in memory like
 * {@link com.steelandcrowns.worldgen.RoadWorldRegistry} — a production
 * version should persist this alongside FactionManager so stock doesn't
 * reset on restart.
 */
public final class TownEconomyManager {

    private static final Map<ServerLevel, Map<BlockPos, TownLedger>> LEDGERS = new ConcurrentHashMap<>();

    public static TownLedger getOrCreate(ServerLevel level, BlockPos settlementAnchor) {
        return LEDGERS.computeIfAbsent(level, l -> new HashMap<>())
                .computeIfAbsent(settlementAnchor, pos -> new TownLedger(new Random(pos.asLong())));
    }

    /** Moves goods from one settlement's ledger to another's — the actual economic effect of a delivered wagon. */
    public static boolean deliver(ServerLevel level, BlockPos from, BlockPos to, TownLedger.Good good, int amount) {
        TownLedger origin = getOrCreate(level, from);
        TownLedger destination = getOrCreate(level, to);
        if (!origin.remove(good, amount)) return false;
        destination.add(good, amount);
        return true;
    }

    private TownEconomyManager() {}
}
