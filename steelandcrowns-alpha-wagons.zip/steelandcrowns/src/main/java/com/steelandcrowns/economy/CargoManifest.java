package com.steelandcrowns.economy;

/** A concrete shipment: this much of this good, moving between two settlements. */
public record CargoManifest(TownLedger.Good good, int amount) {}
