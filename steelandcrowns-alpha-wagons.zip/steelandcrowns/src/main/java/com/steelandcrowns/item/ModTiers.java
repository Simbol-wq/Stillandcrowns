package com.steelandcrowns.item;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;
import java.util.function.Supplier;

/**
 * Historical material tiers replacing the diamond/netherite progression.
 * Balance intent: PADDED < MAIL < PLATE for armor; IRON < STEEL for weapons.
 * Steel deliberately sits ABOVE vanilla iron but has no vanilla-diamond
 * equivalent — top-end power comes from siege/army mechanics, not gear.
 */
public final class ModTiers {

    // Simple custom Tier for tools/weapons (steel sits between iron and diamond stats-wise,
    // but diamond items are removed from progression via VanillaGearRestriction).
    public static final Tier IRON = Tiers.IRON;
    public static final Tier STEEL = new Tier() {
        @Override public int getUses() { return 500; }
        @Override public float getSpeed() { return 7.0f; }
        @Override public float getAttackDamageBonus() { return 3.5f; }
        @Override public int getLevel() { return 3; } // between iron(2) and diamond(3)
        @Override public int getEnchantmentValue() { return 12; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; } // set via datagen
    };

    // Armor materials: name, durability multiplier per slot, protection per slot,
    // enchantability, equip sound, toughness, knockback resistance.
    public static final ArmorMaterial PADDED = simpleArmor("padded",
            5, new int[]{1, 2, 2, 1}, 9, SoundEvents.ARMOR_EQUIP_LEATHER, 0.0f, 0.0f);
    public static final ArmorMaterial MAIL = simpleArmor("mail",
            12, new int[]{2, 4, 5, 2}, 12, SoundEvents.ARMOR_EQUIP_CHAIN, 0.5f, 0.0f);
    public static final ArmorMaterial PLATE = simpleArmor("plate",
            22, new int[]{3, 6, 8, 3}, 10, SoundEvents.ARMOR_EQUIP_IRON, 2.0f, 0.05f);

    private static ArmorMaterial simpleArmor(String name, int durabilityBase, int[] protection,
                                              int enchantability, SoundEvent sound,
                                              float toughness, float knockbackResist) {
        // NOTE: real implementation should be a proper enum or record implementing
        // ArmorMaterial; kept as a factory stub here to keep the skeleton readable.
        return new ArmorMaterial() {
            @Override public int getDurabilityForType(ArmorItem.Type type) {
                return switch (type) {
                    case BOOTS -> 13 * durabilityBase;
                    case LEGGINGS -> 15 * durabilityBase;
                    case CHESTPLATE -> 16 * durabilityBase;
                    case HELMET -> 11 * durabilityBase;
                    default -> durabilityBase;
                };
            }
            @Override public int getDefenseForType(ArmorItem.Type type) {
                return switch (type) {
                    case BOOTS -> protection[0];
                    case LEGGINGS -> protection[1];
                    case CHESTPLATE -> protection[2];
                    case HELMET -> protection[3];
                    default -> 0;
                };
            }
            @Override public int getEnchantmentValue() { return enchantability; }
            @Override public SoundEvent getEquipSound() { return sound; }
            @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
            @Override public String getName() { return "steelandcrowns:" + name; }
            @Override public float getToughness() { return toughness; }
            @Override public float getKnockbackResistance() { return knockbackResist; }
        };
    }

    private ModTiers() {}
}
