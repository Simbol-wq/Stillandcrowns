package com.steelandcrowns.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import java.util.UUID;

/**
 * Generic medieval melee weapon. Differentiates behaviour by {@link Type}:
 * polearms get bonus reach and hit multiple targets in a line, blunt weapons
 * ignore a portion of shield blocking, swords keep vanilla sweep behaviour.
 * Real reach/sweep hit-detection hooks live in a mixin/event handler
 * (not included in this skeleton) — this class only carries the stats
 * and type tag they read from.
 */
public class WeaponItem extends SwordItem {

    public enum Type { SWORD, POLEARM, BLUNT }

    private static final UUID REACH_MODIFIER_UUID = UUID.fromString("c4e1c8b2-5b2a-4f2b-9a9b-6a2f9d3c1e01");

    private final Type type;

    public WeaponItem(Tier tier, int attackDamageIn, float attackSpeedIn, Type type, Properties props) {
        super(tier, attackDamageIn, attackSpeedIn, props);
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    /** Polearms grant +1.5 reach; consumed by the reach-attack event handler. */
    public double getReachBonus() {
        return type == Type.POLEARM ? 1.5d : 0.0d;
    }

    /** Blunt weapons partially ignore shields; used by the combat event handler. */
    public float getShieldBypassFraction() {
        return type == Type.BLUNT ? 0.35f : 0.0f;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Hook point for bleeding/stagger/armor-piercing effects per weapon type.
        return super.hurtEnemy(stack, target, attacker);
    }
}
