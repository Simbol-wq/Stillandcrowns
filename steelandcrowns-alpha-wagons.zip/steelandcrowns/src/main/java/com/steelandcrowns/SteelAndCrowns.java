package com.steelandcrowns;

import com.steelandcrowns.core.ModBlocks;
import com.steelandcrowns.core.ModCreativeTabs;
import com.steelandcrowns.core.ModEntities;
import com.steelandcrowns.core.ModItems;
import com.steelandcrowns.events.RoadChunkPaver;
import com.steelandcrowns.events.VanillaGearRestriction;
import com.steelandcrowns.simulation.WarSimulationTicker;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Root mod class. Steel &amp; Crowns — total medieval immersion.
 * Registers every DeferredRegister subsystem and boots background
 * simulation systems (factions, wars, roads, economy).
 */
@Mod(SteelAndCrowns.MOD_ID)
public class SteelAndCrowns {

    public static final String MOD_ID = "steelandcrowns";

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }

    public SteelAndCrowns() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Registries
        ModItems.ITEMS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);

        // Forge (world) event bus subscriptions
        MinecraftForge.EVENT_BUS.register(new VanillaGearRestriction());
        MinecraftForge.EVENT_BUS.register(new WarSimulationTicker());
        MinecraftForge.EVENT_BUS.register(new RoadChunkPaver());

        modEventBus.addListener(this::registerAttributes);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.KNIGHT.get(), com.steelandcrowns.entity.SoldierEntity.createAttributes().build());
        event.put(ModEntities.GUARD.get(), com.steelandcrowns.entity.SoldierEntity.createAttributes().build());
        event.put(ModEntities.PEASANT.get(), com.steelandcrowns.entity.SoldierEntity.createAttributes().build());
        event.put(ModEntities.KING.get(), com.steelandcrowns.entity.SoldierEntity.createAttributes().build());
        event.put(ModEntities.TREBUCHET.get(), com.steelandcrowns.entity.SiegeEngineEntity.createAttributes().build());
        event.put(ModEntities.BATTERING_RAM.get(), com.steelandcrowns.entity.SiegeEngineEntity.createAttributes().build());
        event.put(ModEntities.WAGON.get(), com.steelandcrowns.entity.WagonEntity.createAttributes().build());
        event.put(ModEntities.COVERED_WAGON.get(), com.steelandcrowns.entity.WagonEntity.createAttributes().build());
    }
}
