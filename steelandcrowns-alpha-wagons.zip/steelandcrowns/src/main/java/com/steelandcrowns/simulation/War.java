package com.steelandcrowns.simulation;

import net.minecraft.core.BlockPos;

/**
 * A single ongoing war between two factions, tracked abstractly (no live
 * entities) until the front line comes near a player. `progress` moves
 * toward attackerFactionId when their computed strength at the contested
 * settlement exceeds the defender's; at 100 the settlement changes owner.
 */
public class War {

    public final String attackerFactionId;
    public final String defenderFactionId;
    public BlockPos contestedSettlement;

    /** -100 (defender routs attacker) .. 100 (settlement falls to attacker). */
    public int progress = 0;

    public War(String attackerFactionId, String defenderFactionId, BlockPos contestedSettlement) {
        this.attackerFactionId = attackerFactionId;
        this.defenderFactionId = defenderFactionId;
        this.contestedSettlement = contestedSettlement;
    }

    public boolean isResolved() {
        return Math.abs(progress) >= 100;
    }
}
