package com.steelandcrowns.simulation;

import com.steelandcrowns.factions.Faction;
import com.steelandcrowns.factions.FactionManager;
import com.steelandcrowns.economy.TownEconomyManager;
import com.steelandcrowns.economy.TownLedger;
import com.steelandcrowns.worldgen.RoadNetworkManager;
import com.steelandcrowns.worldgen.RoadWorldRegistry;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Drives the entire "wars happen without the player" requirement.
 * Runs on a coarse interval (not every tick) to stay cheap: decides new
 * war declarations, advances existing wars abstractly, and resolves
 * settlement captures. When a player is near a contested settlement,
 * a separate (not-yet-implemented) "materializer" should spawn real
 * SoldierEntity/SiegeEngineEntity armies instead of resolving abstractly.
 */
public class WarSimulationTicker {

    private static final int SIMULATION_INTERVAL_TICKS = 20 * 30; // every 30s
    private final List<War> activeWars = new ArrayList<>();
    private final Random random = new Random();
    private final WagonSpawner wagonSpawner = new WagonSpawner();
    private int tickCounter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++tickCounter < SIMULATION_INTERVAL_TICKS) return;
        tickCounter = 0;

        for (ServerLevel level : event.getServer().getAllLevels()) {
            FactionManager manager = FactionManager.get(level);
            considerNewWars(manager);
            advanceWars(manager, level);

            // Roads grow busier/better-maintained over real playtime.
            // Tie this to trade volume/faction wealth for more nuance later;
            // a flat trickle already gives the "trail -> gravel -> paved" arc.
            RoadNetworkManager roads = RoadWorldRegistry.get(level);
            roads.advanceDevelopment(1.5f);
            growSettlementProduction(level, roads);
            wagonSpawner.trySpawnWagons(level, roads);
        }
    }

    /** Every settlement slowly produces goods (farming/mining/crafting abstracted away)
     *  so surpluses keep reappearing and wagon logistics stays an ongoing loop, not a one-off drain. */
    private void growSettlementProduction(ServerLevel level, RoadNetworkManager roads) {
        for (RoadNetworkManager.RoadNode node : roads.getNodes()) {
            TownLedger ledger = TownEconomyManager.getOrCreate(level, node.anchor());
            TownLedger.Good[] goods = TownLedger.Good.values();
            TownLedger.Good produced = goods[random.nextInt(goods.length)];
            ledger.add(produced, 3 + random.nextInt(5));
        }
    }

    /** AI decision: a faction may declare war on a weaker rival with treasury to spare. */
    private void considerNewWars(FactionManager manager) {
        for (Faction aggressor : manager.all().values()) {
            if (aggressor.treasury < 500) continue; // can't afford a campaign
            for (Faction target : manager.all().values()) {
                if (target == aggressor || aggressor.isAtWarWith(target.id)) continue;
                boolean aggressorStronger = aggressor.militaryStrength > target.militaryStrength * 1.3;
                boolean rollSucceeds = random.nextFloat() < 0.05f; // 5% chance per interval
                if (aggressorStronger && rollSucceeds) {
                    aggressor.declareWarOn(target.id);
                    activeWars.add(new War(aggressor.id, target.id,
                            target.settlements.isEmpty() ? target.capital : target.settlements.get(0)));
                }
            }
        }
    }

    /** Push each active war's progress based on relative strength, then resolve if finished. */
    private void advanceWars(FactionManager manager, ServerLevel level) {
        List<War> resolved = new ArrayList<>();
        for (War war : activeWars) {
            Faction attacker = manager.get(war.attackerFactionId);
            Faction defender = manager.get(war.defenderFactionId);
            if (attacker == null || defender == null) { resolved.add(war); continue; }

            int delta = Integer.compare(attacker.militaryStrength, defender.militaryStrength)
                    * (2 + random.nextInt(4));
            war.progress += delta;

            if (war.isResolved()) {
                if (war.progress > 0) {
                    // Attacker captures the settlement.
                    defender.settlements.remove(war.contestedSettlement);
                    attacker.settlements.add(war.contestedSettlement);
                }
                resolved.add(war);
            }
        }
        activeWars.removeAll(resolved);
    }
}
