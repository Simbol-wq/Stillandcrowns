package com.steelandcrowns.simulation;

import com.steelandcrowns.core.ModEntities;
import com.steelandcrowns.economy.CargoManifest;
import com.steelandcrowns.economy.TownLedger;
import com.steelandcrowns.economy.TownEconomyManager;
import com.steelandcrowns.entity.SoldierEntity;
import com.steelandcrowns.entity.WagonEntity;
import com.steelandcrowns.worldgen.RoadNetworkManager;
import net.minecraft.server.level.ServerLevel;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Keeps roughly one wagon in transit per developed road edge — but unlike a
 * cosmetic patrol loop, every trip has a reason: a real settlement surplus
 * (from {@link TownLedger}), a real cargo amount, and a real
 * {@link SoldierEntity} (peasant) riding as driver, spawned fresh for each run.
 */
public class WagonSpawner {

    private static final int MAX_WAGONS_PER_EDGE = 1;
    private static final int SURPLUS_THRESHOLD = 50;
    private static final int SHIPMENT_SIZE = 20;

    private final Map<RoadNetworkManager.RoadEdge, Integer> activeWagonCount = new HashMap<>();
    private final Random random = new Random();

    public void trySpawnWagons(ServerLevel level, RoadNetworkManager roads) {
        for (RoadNetworkManager.RoadEdge edge : roads.getEdges()) {
            if (edge.development <= 0f || edge.waypoints.isEmpty()) continue;
            if (activeWagonCount.getOrDefault(edge, 0) >= MAX_WAGONS_PER_EDGE) continue;
            if (random.nextFloat() > 0.15f) continue; // don't spawn one every single interval

            var startWaypoint = edge.waypoints.get(0);
            if (!level.isLoaded(startWaypoint.pos())) continue;

            CargoManifest cargo = pickCargo(level, edge);
            if (cargo == null) continue; // nothing worth shipping right now — no surplus anywhere on this edge

            WagonEntity wagon = (random.nextBoolean()
                    ? ModEntities.WAGON.get()
                    : ModEntities.COVERED_WAGON.get()).create(level);
            if (wagon == null) continue;
            wagon.moveTo(startWaypoint.pos().getX() + 0.5, startWaypoint.pos().getY() + 1,
                    startWaypoint.pos().getZ() + 0.5, 0f, 0f);
            wagon.assignRun(edge, true, cargo, this::onWagonRemoved);
            level.addFreshEntity(wagon);

            SoldierEntity driver = ModEntities.PEASANT.get().create(level);
            if (driver != null) {
                driver.moveTo(wagon.getX(), wagon.getY(), wagon.getZ(), 0f, 0f);
                level.addFreshEntity(driver);
                driver.startRiding(wagon, true);
            }

            activeWagonCount.merge(edge, 1, Integer::sum);
        }
    }

    /** Looks for a good either settlement has a genuine surplus of, worth hauling to the other. */
    private CargoManifest pickCargo(ServerLevel level, RoadNetworkManager.RoadEdge edge) {
        TownLedger origin = TownEconomyManager.getOrCreate(level, edge.from.anchor());
        for (TownLedger.Good good : TownLedger.Good.values()) {
            if (origin.hasSurplus(good, SURPLUS_THRESHOLD)) {
                return new CargoManifest(good, SHIPMENT_SIZE);
            }
        }
        // Check the other direction too — trade should be able to flow either way.
        TownLedger destination = TownEconomyManager.getOrCreate(level, edge.to.anchor());
        for (TownLedger.Good good : TownLedger.Good.values()) {
            if (destination.hasSurplus(good, SURPLUS_THRESHOLD)) {
                return new CargoManifest(good, SHIPMENT_SIZE);
            }
        }
        return null;
    }

    public void onWagonRemoved(RoadNetworkManager.RoadEdge edge) {
        activeWagonCount.computeIfPresent(edge, (k, v) -> Math.max(0, v - 1));
    }
}
