package com.steelandcrowns.factions;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;

/**
 * World-level registry of all factions. In a full implementation this
 * extends SavedData and is fetched via
 * level.getDataStorage().computeIfAbsent(FactionManager::load, FactionManager::new, "steelandcrowns_factions").
 * NBT (de)serialization is omitted here to keep the skeleton focused on
 * structure; wire it up alongside Faction's own save/load.
 */
public class FactionManager extends SavedData {

    private final Map<String, Faction> factions = new HashMap<>();

    public static FactionManager get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                (tag) -> new FactionManager(), FactionManager::new, "steelandcrowns_factions");
    }

    public Faction getOrCreate(String id, String displayName, net.minecraft.core.BlockPos capital) {
        return factions.computeIfAbsent(id, k -> {
            setDirty();
            return new Faction(id, displayName, capital);
        });
    }

    public Faction get(String id) {
        return factions.get(id);
    }

    public Map<String, Faction> all() {
        return factions;
    }

    @Override
    public net.minecraft.nbt.CompoundTag save(net.minecraft.nbt.CompoundTag tag) {
        // TODO: serialize each Faction (settlements, relations, treasury, ruler UUID).
        return tag;
    }
}
