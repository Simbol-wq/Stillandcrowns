package com.steelandcrowns.factions;

import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A single kingdom/faction. Persisted inside {@link FactionManager}'s
 * SavedData (NBT read/write omitted from this skeleton for brevity —
 * add save()/load(CompoundTag) mirroring these fields).
 */
public class Faction {

    public final String id;
    public String displayName;
    public BlockPos capital;

    /** Settlement anchor points (village/outpost/castle centers) owned by this faction. */
    public final List<BlockPos> settlements = new ArrayList<>();

    /** UUID of the KingEntity currently ruling, if alive. */
    public UUID rulerUuid;

    /** Treasury used for army upkeep, mercenary hire, and construction. */
    public long treasury;

    /** Relative military strength, derived from settlement count, garrisons, and treasury. */
    public int militaryStrength;

    /** Relations with other faction ids: -100 (war) .. 100 (allied). */
    public final Map<String, Integer> relations = new HashMap<>();

    /** Tax rate applied to trade passing through this faction's settlements (0.0 - 0.5). */
    public float taxRate = 0.1f;

    public Faction(String id, String displayName, BlockPos capital) {
        this.id = id;
        this.displayName = displayName;
        this.capital = capital;
    }

    public boolean isAtWarWith(String otherFactionId) {
        return relations.getOrDefault(otherFactionId, 0) <= -50;
    }

    public void declareWarOn(String otherFactionId) {
        relations.put(otherFactionId, -100);
    }
}
