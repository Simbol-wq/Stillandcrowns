package com.steelandcrowns.client.renderer;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.client.model.ModModelLayers;
import com.steelandcrowns.client.model.WagonModel;
import com.steelandcrowns.entity.WagonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class WagonRenderer extends MobRenderer<WagonEntity, WagonModel> {

    private static final ResourceLocation TEXTURE = SteelAndCrowns.id("textures/entity/wagon.png");

    public WagonRenderer(EntityRendererProvider.Context context) {
        super(context, new WagonModel(context.bakeLayer(ModModelLayers.WAGON)), 0.7f);
    }

    @Override
    public ResourceLocation getTextureLocation(WagonEntity entity) {
        return TEXTURE;
    }
}
