package com.steelandcrowns.client;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.client.model.ModModelLayers;
import com.steelandcrowns.client.model.WagonModel;
import com.steelandcrowns.client.model.CoveredWagonModel;
import com.steelandcrowns.client.renderer.CoveredWagonRenderer;
import com.steelandcrowns.client.renderer.SoldierRenderer;
import com.steelandcrowns.client.renderer.WagonRenderer;
import com.steelandcrowns.core.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * All client-only wiring lives here: which renderer/texture each entity
 * uses, and the wagon's LayerDefinition registration. Kept out of the main
 * mod class so a dedicated (headless) server never touches client classes.
 */
@Mod.EventBusSubscriber(modid = SteelAndCrowns.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ModModelLayers.WAGON, WagonModel::createBodyLayer);
        event.registerLayerDefinition(ModModelLayers.COVERED_WAGON, CoveredWagonModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PEASANT.get(),
                ctx -> new SoldierRenderer<>(ctx, SteelAndCrowns.id("textures/entity/peasant.png")));
        event.registerEntityRenderer(ModEntities.GUARD.get(),
                ctx -> new SoldierRenderer<>(ctx, SteelAndCrowns.id("textures/entity/guard.png")));
        event.registerEntityRenderer(ModEntities.KNIGHT.get(),
                ctx -> new SoldierRenderer<>(ctx, SteelAndCrowns.id("textures/entity/knight.png")));
        event.registerEntityRenderer(ModEntities.KING.get(),
                ctx -> new SoldierRenderer<>(ctx, SteelAndCrowns.id("textures/entity/king.png")));
        event.registerEntityRenderer(ModEntities.WAGON.get(), WagonRenderer::new);
        event.registerEntityRenderer(ModEntities.COVERED_WAGON.get(), CoveredWagonRenderer::new);
    }

    private ClientSetup() {}
}
