package com.steelandcrowns.client.model;

import com.steelandcrowns.entity.WagonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Covered merchant wagon: taller body, enclosed cargo sides and a cloth roof. */
public class CoveredWagonModel extends EntityModel<WagonEntity> {
    private final ModelPart body;
    private final ModelPart cart;
    private final ModelPart[] legs = new ModelPart[4];
    private final ModelPart[] wheels = new ModelPart[4];

    public CoveredWagonModel(ModelPart root) {
        body = root.getChild("body");
        cart = root.getChild("cart");
        legs[0] = body.getChild("leg_fl");
        legs[1] = body.getChild("leg_fr");
        legs[2] = body.getChild("leg_bl");
        legs[3] = body.getChild("leg_br");
        wheels[0] = cart.getChild("wheel_fl");
        wheels[1] = cart.getChild("wheel_fr");
        wheels[2] = cart.getChild("wheel_bl");
        wheels[3] = cart.getChild("wheel_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3, -6, -5, 6, 6, 10),
                PartPose.offset(0, 14, -4));
        body.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2, -4, -5, 4, 4, 5),
                PartPose.offsetAndRotation(0, -5, -5, -0.30f, 0, 0));
        addLeg(body, "leg_fl", -2.5f, 0, -3);
        addLeg(body, "leg_fr",  2.5f, 0, -3);
        addLeg(body, "leg_bl", -2.5f, 0,  4);
        addLeg(body, "leg_br",  2.5f, 0,  4);

        PartDefinition cart = root.addOrReplaceChild("cart",
                CubeListBuilder.create().texOffs(0, 26).addBox(-5, -2, 0, 10, 2, 10),
                PartPose.offset(0, 18, 6));
        cart.addOrReplaceChild("wall_left",
                CubeListBuilder.create().texOffs(40, 10).addBox(0, -6, 0, 1, 6, 10),
                PartPose.offset(-5, -2, 0));
        cart.addOrReplaceChild("wall_right",
                CubeListBuilder.create().texOffs(40, 10).addBox(0, -6, 0, 1, 6, 10),
                PartPose.offset(4, -2, 0));
        cart.addOrReplaceChild("wall_front",
                CubeListBuilder.create().texOffs(0, 38).addBox(0, -6, 0, 10, 6, 1),
                PartPose.offset(-5, -2, 0));
        cart.addOrReplaceChild("wall_back",
                CubeListBuilder.create().texOffs(0, 38).addBox(0, -6, 0, 10, 6, 1),
                PartPose.offset(-5, -2, 9));

        // Four wooden roof supports and a broad canvas roof.
        cart.addOrReplaceChild("post_fl",
                CubeListBuilder.create().texOffs(48, 26).addBox(-1, -12, -1, 1, 10, 1),
                PartPose.offset(-4, -2, 1));
        cart.addOrReplaceChild("post_fr",
                CubeListBuilder.create().texOffs(48, 26).addBox(0, -12, -1, 1, 10, 1),
                PartPose.offset(4, -2, 1));
        cart.addOrReplaceChild("post_bl",
                CubeListBuilder.create().texOffs(48, 26).addBox(-1, -12, 0, 1, 10, 1),
                PartPose.offset(-4, -2, 9));
        cart.addOrReplaceChild("post_br",
                CubeListBuilder.create().texOffs(48, 26).addBox(0, -12, 0, 1, 10, 1),
                PartPose.offset(4, -2, 9));
        cart.addOrReplaceChild("roof",
                CubeListBuilder.create().texOffs(0, 52).addBox(-6, -14, -1, 12, 1, 12),
                PartPose.offset(0, -2, 0));

        addWheel(cart, "wheel_fl", -5.5f, 0, 1.5f);
        addWheel(cart, "wheel_fr",  4.5f, 0, 1.5f);
        addWheel(cart, "wheel_bl", -5.5f, 0, 7.5f);
        addWheel(cart, "wheel_br",  4.5f, 0, 7.5f);
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addLeg(PartDefinition p, String n, float x, float y, float z) {
        p.addOrReplaceChild(n, CubeListBuilder.create().texOffs(32, 0).addBox(-1, 0, -1, 2, 8, 2),
                PartPose.offset(x, y, z));
    }

    private static void addWheel(PartDefinition p, String n, float x, float y, float z) {
        p.addOrReplaceChild(n, CubeListBuilder.create().texOffs(22, 38).addBox(-0.5f, -3, -3, 1, 6, 6),
                PartPose.offset(x, y, z));
    }

    @Override
    public void setupAnim(WagonEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float swing = Mth.cos(limbSwing * 0.6662f) * 1.2f * limbSwingAmount;
        legs[0].xRot = swing; legs[3].xRot = swing;
        legs[1].xRot = -swing; legs[2].xRot = -swing;
        float spin = limbSwing * 0.5f;
        for (ModelPart wheel : wheels) wheel.xRot = spin;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        body.render(poseStack, vc, light, overlay, r, g, b, a);
        cart.render(poseStack, vc, light, overlay, r, g, b, a);
    }
}
