package com.steelandcrowns.client.renderer;

import com.steelandcrowns.entity.SoldierEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Peasant/Guard/Knight/King all share this renderer, differing only by the
 * texture path passed in at registration — reuses vanilla's player body
 * geometry (see {@link ModelLayers#PLAYER}) instead of building custom
 * humanoid geometry, since Steve proportions already fit a person in armor
 * or robes just fine. Armor equipped on these entities renders through the
 * normal HumanoidArmorLayer using our ModTiers armor materials — no extra
 * per-entity work needed there.
 */
public class SoldierRenderer<T extends SoldierEntity> extends HumanoidMobRenderer<T, HumanoidModel<T>> {

    private final ResourceLocation texture;

    public SoldierRenderer(EntityRendererProvider.Context context, ResourceLocation texture) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
        this.texture = texture;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
}
