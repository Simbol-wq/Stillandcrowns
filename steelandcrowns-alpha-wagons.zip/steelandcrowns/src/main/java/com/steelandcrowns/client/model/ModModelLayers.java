package com.steelandcrowns.client.model;

import com.steelandcrowns.SteelAndCrowns;
import net.minecraft.client.model.geom.ModelLayerLocation;

public final class ModModelLayers {
    public static final ModelLayerLocation WAGON =
            new ModelLayerLocation(SteelAndCrowns.id("wagon"), "main");
    public static final ModelLayerLocation COVERED_WAGON =
            new ModelLayerLocation(SteelAndCrowns.id("covered_wagon"), "main");

    private ModModelLayers() {}
}
