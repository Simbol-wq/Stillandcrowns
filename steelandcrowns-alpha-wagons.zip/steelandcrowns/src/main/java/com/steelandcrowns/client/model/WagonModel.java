package com.steelandcrowns.client.model;

import com.steelandcrowns.entity.WagonEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

/**
 * "Horse + cart" combined low-poly model, hand-built from cuboids — the
 * direct code equivalent of what you'd normally box out in Blockbench.
 * Texture sheet is 64x64 (see textures/entity/wagon.png); UV offsets below
 * MUST stay in sync with that texture's painted regions.
 *
 * Geometry is intentionally blocky/voxel-ish to match the game's own
 * aesthetic rather than aiming for a smooth/rounded horse — pivot numbers
 * are a reasonable first pass, easy to nudge once seen in-game (adjust the
 * PartPose.offset calls below, nothing else needs to change).
 */
public class WagonModel extends EntityModel<WagonEntity> {

    private final ModelPart body;
    private final ModelPart cartBed;
    private final ModelPart[] legs = new ModelPart[4];
    private final ModelPart[] wheels = new ModelPart[4];

    public WagonModel(ModelPart root) {
        this.body = root.getChild("body");
        this.cartBed = root.getChild("cart_bed");
        this.legs[0] = body.getChild("leg_front_left");
        this.legs[1] = body.getChild("leg_front_right");
        this.legs[2] = body.getChild("leg_back_left");
        this.legs[3] = body.getChild("leg_back_right");
        this.wheels[0] = cartBed.getChild("wheel_front_left");
        this.wheels[1] = cartBed.getChild("wheel_front_right");
        this.wheels[2] = cartBed.getChild("wheel_back_left");
        this.wheels[3] = cartBed.getChild("wheel_back_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3, -6, -5, 6, 6, 10),
                PartPose.offset(0f, 14f, -4f)); // horse body, forward of the cart

        body.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2, -4, -5, 4, 4, 5),
                PartPose.offsetAndRotation(0f, -5f, -5f, -0.35f, 0f, 0f)); // neck angled up

        addLeg(body, "leg_front_left", -2.5f, 0f, -3f);
        addLeg(body, "leg_front_right", 2.5f, 0f, -3f);
        addLeg(body, "leg_back_left", -2.5f, 0f, 4f);
        addLeg(body, "leg_back_right", 2.5f, 0f, 4f);

        PartDefinition cartBed = root.addOrReplaceChild("cart_bed",
                CubeListBuilder.create().texOffs(0, 26).addBox(-5, -2, 0, 10, 2, 10),
                PartPose.offset(0f, 18f, 6f)); // trailing behind the horse

        cartBed.addOrReplaceChild("wall_left",
                CubeListBuilder.create().texOffs(40, 10).addBox(0, -3, 0, 1, 3, 10),
                PartPose.offset(-5f, -2f, 0f));
        cartBed.addOrReplaceChild("wall_right",
                CubeListBuilder.create().texOffs(40, 10).addBox(0, -3, 0, 1, 3, 10),
                PartPose.offset(4f, -2f, 0f));
        cartBed.addOrReplaceChild("wall_front",
                CubeListBuilder.create().texOffs(0, 38).addBox(0, -3, 0, 10, 3, 1),
                PartPose.offset(-5f, -2f, 0f));
        cartBed.addOrReplaceChild("wall_back",
                CubeListBuilder.create().texOffs(0, 38).addBox(0, -3, 0, 10, 3, 1),
                PartPose.offset(-5f, -2f, 9f));

        addWheel(cartBed, "wheel_front_left", -5.5f, 0f, 1.5f);
        addWheel(cartBed, "wheel_front_right", 4.5f, 0f, 1.5f);
        addWheel(cartBed, "wheel_back_left", -5.5f, 0f, 7.5f);
        addWheel(cartBed, "wheel_back_right", 4.5f, 0f, 7.5f);

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addLeg(PartDefinition parent, String name, float x, float y, float z) {
        parent.addOrReplaceChild(name,
                CubeListBuilder.create().texOffs(32, 0).addBox(-1, 0, -1, 2, 8, 2),
                PartPose.offset(x, y, z));
    }

    private static void addWheel(PartDefinition parent, String name, float x, float y, float z) {
        parent.addOrReplaceChild(name,
                CubeListBuilder.create().texOffs(22, 38).addBox(-0.5f, -3, -3, 1, 6, 6),
                PartPose.offset(x, y, z));
    }

    @Override
    public void setupAnim(WagonEntity entity, float limbSwing, float limbSwingAmount,
                           float ageInTicks, float netHeadYaw, float headPitch) {
        float swing = net.minecraft.util.Mth.cos(limbSwing * 0.6662f) * 1.2f * limbSwingAmount;
        legs[0].xRot = swing;
        legs[3].xRot = swing;
        legs[1].xRot = -swing;
        legs[2].xRot = -swing;

        float wheelSpin = limbSwing * 0.5f;
        for (ModelPart wheel : wheels) {
            wheel.xRot = wheelSpin;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight,
                                int packedOverlay, float red, float green, float blue, float alpha) {
        body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        cartBed.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
