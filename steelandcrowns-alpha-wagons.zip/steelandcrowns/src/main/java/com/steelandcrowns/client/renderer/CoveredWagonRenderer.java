package com.steelandcrowns.client.renderer;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.client.model.CoveredWagonModel;
import com.steelandcrowns.client.model.ModModelLayers;
import com.steelandcrowns.entity.WagonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CoveredWagonRenderer extends MobRenderer<WagonEntity, CoveredWagonModel> {
    private static final ResourceLocation TEXTURE =
            SteelAndCrowns.id("textures/entity/covered_wagon.png");

    public CoveredWagonRenderer(EntityRendererProvider.Context context) {
        super(context, new CoveredWagonModel(context.bakeLayer(ModModelLayers.COVERED_WAGON)), 0.7f);
    }

    @Override
    public ResourceLocation getTextureLocation(WagonEntity entity) {
        return TEXTURE;
    }
}
