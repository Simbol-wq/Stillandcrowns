package com.steelandcrowns.events;

import com.steelandcrowns.worldgen.RoadNetworkManager;
import com.steelandcrowns.worldgen.RoadWorldRegistry;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Whenever a chunk finishes loading, pave whatever road waypoints happen to
 * fall inside it at their current development stage. This is what makes
 * roads appear "gradually" to the player — nothing is placed ahead of time
 * across unloaded terrain, and re-visiting an old trail later shows it
 * upgraded to gravel/paved stone once its development has grown.
 */
public class RoadChunkPaver {

    @SubscribeEvent
    public void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getChunk() instanceof LevelChunk)) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        ChunkPos chunkPos = event.getChunk().getPos();
        RoadNetworkManager roads = RoadWorldRegistry.get(serverLevel);
        roads.paveChunk(serverLevel, chunkPos);
    }
}
