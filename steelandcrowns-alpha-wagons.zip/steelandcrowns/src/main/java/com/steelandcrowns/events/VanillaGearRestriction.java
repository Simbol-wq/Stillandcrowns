package com.steelandcrowns.events;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Set;

/**
 * Enforces "Total Medieval" progression: blocks the player from acquiring or
 * equipping vanilla elite-tier items (diamond/netherite gear, elytra).
 * Two layers: prevent pickup entirely, and as a safety net, strip/cancel
 * equip if one slips through (commands, other mods, loot tables).
 */
public class VanillaGearRestriction {

    private static final Set<net.minecraft.world.item.Item> BANNED_ITEMS = Set.of(
            Items.DIAMOND_SWORD, Items.DIAMOND_AXE, Items.DIAMOND_PICKAXE,
            Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            Items.NETHERITE_SWORD, Items.NETHERITE_AXE, Items.NETHERITE_PICKAXE,
            Items.NETHERITE_SHOVEL, Items.NETHERITE_HOE,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            Items.ELYTRA, Items.NETHERITE_INGOT, Items.DIAMOND
    );

    @SubscribeEvent
    public void onPickup(EntityItemPickupEvent event) {
        ItemStack stack = event.getItem().getItem();
        if (BANNED_ITEMS.contains(stack.getItem())) {
            event.setCanceled(true);
            event.getItem().discard();
        }
    }

    @SubscribeEvent
    public void onEquipmentChange(LivingEquipmentChangeEvent event) {
        ItemStack to = event.getTo();
        if (!to.isEmpty() && BANNED_ITEMS.contains(to.getItem())) {
            // Force-unequip: drop it and clear the slot.
            event.getEntity().level().addFreshEntity(
                    new net.minecraft.world.entity.item.ItemEntity(
                            event.getEntity().level(),
                            event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(),
                            to.copy()));
            event.getEntity().setItemSlot(event.getSlot(), ItemStack.EMPTY);
        }
    }
}
