package com.steelandcrowns.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * Base for player/NPC-operated siege engines (trebuchet, catapult, battering
 * ram). Movement speed is intentionally very low; damage is dealt via a
 * fired projectile entity (trebuchet/catapult) or a periodic melee-style
 * impact check against blocks directly ahead (battering ram), both of which
 * route into {@link com.steelandcrowns.block.DestructibleWallBlock} HP.
 */
public class SiegeEngineEntity extends PathfinderMob {

    private int reloadTicks = 0;

    public SiegeEngineEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.08D)
                .add(Attributes.ATTACK_DAMAGE, 25.0D); // wall-damage baseline
    }

    @Override
    protected void registerGoals() {
        // No default combat goals — driven by player control or a
        // faction-army AI controller that targets enemy fortifications.
    }

    // TODO: fireProjectile()/swingRam() called on a fixed reload timer,
    // dealing structural damage to DestructibleWallBlock instances in range.
}
