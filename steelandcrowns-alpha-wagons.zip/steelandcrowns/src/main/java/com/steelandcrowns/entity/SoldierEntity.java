package com.steelandcrowns.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Base class for all faction-affiliated NPCs (peasant, guard, knight).
 * Carries a factionId used by AI goals to decide who is friend/foe and by
 * {@link com.steelandcrowns.simulation.WarSimulationTicker} when a background
 * war "materializes" into real entities near the player.
 */
public class SoldierEntity extends PathfinderMob {

    @Nullable
    private String factionId;

    public SoldierEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob0Attributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    // placeholder to keep AttributeSupplier.builder() call explicit in one place
    private static AttributeSupplier.Builder Mob0Attributes() {
        return net.minecraft.world.entity.LivingEntity.createLivingAttributes();
    }

    @Override
    protected void registerGoals() {
        // Patrol along the settlement's road network when idle.
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new MoveTowardsRestrictionGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 0.8D));
        // Attack members of hostile factions and monsters; friendly-fire is
        // excluded by checking factionId equality/alliance in a predicate
        // (full predicate wiring omitted from this skeleton).
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    @Nullable
    public String getFactionId() {
        return factionId;
    }

    public void setFactionId(@Nullable String factionId) {
        this.factionId = factionId;
    }
}
