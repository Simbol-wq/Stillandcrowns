package com.steelandcrowns.entity;

import com.steelandcrowns.economy.CargoManifest;
import com.steelandcrowns.economy.TownEconomyManager;
import com.steelandcrowns.worldgen.RoadNetworkManager;
import com.steelandcrowns.worldgen.RoadPathfinder.RoadWaypoint;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

import java.util.EnumSet;
import java.util.List;
import java.util.function.Consumer;

/**
 * A real merchant run, not set dressing: this wagon carries an actual
 * {@link CargoManifest} pulled from the origin settlement's surplus (see
 * {@link com.steelandcrowns.simulation.WagonSpawner}), and applies that
 * delivery to {@link TownEconomyManager} the moment it reaches the far end —
 * goods genuinely move between towns' stock, not just the wagon's position.
 * A live {@link SoldierEntity} (peasant variant) rides it as the driver,
 * spawned alongside the wagon and dismounted when the run ends.
 */
public class WagonEntity extends PathfinderMob {

    private RoadNetworkManager.RoadEdge assignedEdge;
    private CargoManifest cargo;
    private int waypointIndex = 0;
    private boolean forward = true;
    private Consumer<RoadNetworkManager.RoadEdge> onRunFinished;

    public WagonEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.18D) // slower than a mounted rider — it's a loaded cart
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    public void assignRun(RoadNetworkManager.RoadEdge edge, boolean startForward, CargoManifest cargo,
                           Consumer<RoadNetworkManager.RoadEdge> onRunFinished) {
        this.assignedEdge = edge;
        this.forward = startForward;
        this.waypointIndex = startForward ? 0 : edge.waypoints.size() - 1;
        this.cargo = cargo;
        this.onRunFinished = onRunFinished;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FollowRoadGoal(this));
    }

    // --- driver seat: the peasant rides visibly on top, roughly over the horse's back ---
    @Override
    protected void positionRider(Entity passenger, MoveFunction callback) {
        if (hasPassenger(passenger)) {
            callback.accept(passenger, this.getX(), this.getY() + getPassengersRidingOffset(), this.getZ());
        }
    }

    @Override
    public double getPassengersRidingOffset() {
        return 1.7;
    }

    private void completeDelivery() {
        if (!(level() instanceof ServerLevel serverLevel) || assignedEdge == null || cargo == null) return;

        // `forward` has already been flipped to the next leg by the time this
        // fires (see FollowRoadGoal), so the leg that just finished ran the
        // OTHER direction from the current flag.
        BlockPos origin = forward ? assignedEdge.to.anchor() : assignedEdge.from.anchor();
        BlockPos destination = forward ? assignedEdge.from.anchor() : assignedEdge.to.anchor();
        TownEconomyManager.deliver(serverLevel, origin, destination, cargo.good(), cargo.amount());

        if (onRunFinished != null) {
            onRunFinished.accept(assignedEdge);
        }
        // Driver dismounts and wanders off into the settlement rather than
        // popping out of existence with the cart — reads as an actual person
        // finishing their trip, not cargo despawning.
        this.getPassengers().forEach(Entity::stopRiding);
        this.discard();
    }

    /** Drives the wagon along its assigned edge's waypoint list, delivering cargo at each end. */
    private static class FollowRoadGoal extends Goal {
        private final WagonEntity wagon;
        private static final double ARRIVAL_DISTANCE_SQ = 4.0;

        FollowRoadGoal(WagonEntity wagon) {
            this.wagon = wagon;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return wagon.assignedEdge != null && !wagon.assignedEdge.waypoints.isEmpty();
        }

        @Override
        public void tick() {
            List<RoadWaypoint> waypoints = wagon.assignedEdge.waypoints;
            RoadWaypoint target = waypoints.get(wagon.waypointIndex);
            BlockPos targetPos = target.pos();

            wagon.getNavigation().moveTo(
                    targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5, 1.0D);

            if (wagon.distanceToSqr(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5)
                    < ARRIVAL_DISTANCE_SQ) {
                advanceWaypoint(waypoints);
            }
        }

        private void advanceWaypoint(List<RoadWaypoint> waypoints) {
            boolean reachedEnd;
            if (wagon.forward) {
                wagon.waypointIndex++;
                reachedEnd = wagon.waypointIndex >= waypoints.size();
                if (reachedEnd) wagon.waypointIndex = waypoints.size() - 1;
            } else {
                wagon.waypointIndex--;
                reachedEnd = wagon.waypointIndex < 0;
                if (reachedEnd) wagon.waypointIndex = 0;
            }
            if (reachedEnd) {
                wagon.forward = !wagon.forward; // flip so completeDelivery reads the leg just finished correctly
                wagon.completeDelivery(); // one-way haul per wagon; spawner sends a fresh one for the return trip
            }
        }
    }
}
