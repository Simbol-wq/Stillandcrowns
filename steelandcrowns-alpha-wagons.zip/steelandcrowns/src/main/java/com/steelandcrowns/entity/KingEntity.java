package com.steelandcrowns.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * Faction ruler entity. Holds no unique combat logic beyond SoldierEntity,
 * but is the anchor NPC the player interacts with for vassalage/diplomacy
 * dialogue (declare fealty, request mercenary contract, challenge for the
 * throne). Its death/removal is a key input to {@link com.steelandcrowns.factions.Faction}
 * succession logic.
 */
public class KingEntity extends SoldierEntity {

    public KingEntity(EntityType<? extends SoldierEntity> type, Level level) {
        super(type, level);
    }

    // TODO: openMenu(Player) -> vassalage / diplomacy GUI (accept fealty,
    // grant fief -> hands player a ROYAL_CHARTER item, declare war on request, etc.)
}
