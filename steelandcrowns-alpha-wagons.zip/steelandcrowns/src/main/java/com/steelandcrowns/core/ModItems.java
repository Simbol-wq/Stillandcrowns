package com.steelandcrowns.core;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.item.ModTiers;
import com.steelandcrowns.item.WeaponItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * All custom medieval items. Vanilla diamond/netherite gear is intentionally
 * NOT extended here — see {@link com.steelandcrowns.events.VanillaGearRestriction}
 * for the corresponding removal/blocking logic.
 */
public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SteelAndCrowns.MOD_ID);

    // --- Weapons ---
    public static final RegistryObject<Item> LONGSWORD = ITEMS.register("longsword",
            () -> new WeaponItem(ModTiers.STEEL, 3, -2.2f, WeaponItem.Type.SWORD,
                    new Item.Properties()));

    public static final RegistryObject<Item> HALBERD = ITEMS.register("halberd",
            () -> new WeaponItem(ModTiers.STEEL, 5, -3.0f, WeaponItem.Type.POLEARM,
                    new Item.Properties()));

    public static final RegistryObject<Item> SPEAR = ITEMS.register("spear",
            () -> new WeaponItem(ModTiers.IRON, 2, -2.8f, WeaponItem.Type.POLEARM,
                    new Item.Properties()));

    public static final RegistryObject<Item> MACE = ITEMS.register("mace",
            () -> new WeaponItem(ModTiers.STEEL, 4, -2.6f, WeaponItem.Type.BLUNT,
                    new Item.Properties()));

    public static final RegistryObject<Item> HEAVY_CROSSBOW = ITEMS.register("heavy_crossbow",
            () -> new CrossbowItem(new Item.Properties().durability(200)));

    // --- Shields ---
    public static final RegistryObject<Item> KITE_SHIELD = ITEMS.register("kite_shield",
            () -> new Item(new Item.Properties().durability(280)));

    public static final RegistryObject<Item> BUCKLER = ITEMS.register("buckler",
            () -> new Item(new Item.Properties().durability(150)));

    // --- Armor (padded/mail/plate sets, per-tier) ---
    public static final RegistryObject<Item> PADDED_CHESTPLATE = ITEMS.register("padded_chestplate",
            () -> new ArmorItem(ModTiers.PADDED, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> CHAINMAIL_HAUBERK = ITEMS.register("chainmail_hauberk",
            () -> new ArmorItem(ModTiers.MAIL, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> PLATE_CUIRASS = ITEMS.register("plate_cuirass",
            () -> new ArmorItem(ModTiers.PLATE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> VISORED_HELMET = ITEMS.register("visored_helmet",
            () -> new ArmorItem(ModTiers.PLATE, ArmorItem.Type.HELMET, new Item.Properties()));

    // --- Materials / crafting chain ---
    public static final RegistryObject<Item> STEEL_INGOT = ITEMS.register("steel_ingot",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TANNED_LEATHER = ITEMS.register("tanned_leather",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ROYAL_CHARTER = ITEMS.register("royal_charter",
            () -> new Item(new Item.Properties().stacksTo(1))); // used for vassalage/fief grants
}
