package com.steelandcrowns.core;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.entity.KingEntity;
import com.steelandcrowns.entity.SiegeEngineEntity;
import com.steelandcrowns.entity.SoldierEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SteelAndCrowns.MOD_ID);

    public static final RegistryObject<EntityType<SoldierEntity>> KNIGHT =
            ENTITIES.register("knight", () -> EntityType.Builder.of(SoldierEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).build(SteelAndCrowns.MOD_ID + ":knight"));

    public static final RegistryObject<EntityType<SoldierEntity>> GUARD =
            ENTITIES.register("guard", () -> EntityType.Builder.of(SoldierEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).build(SteelAndCrowns.MOD_ID + ":guard"));

    public static final RegistryObject<EntityType<SoldierEntity>> PEASANT =
            ENTITIES.register("peasant", () -> EntityType.Builder.of(SoldierEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).build(SteelAndCrowns.MOD_ID + ":peasant"));

    public static final RegistryObject<EntityType<KingEntity>> KING =
            ENTITIES.register("king", () -> EntityType.Builder.of(KingEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).build(SteelAndCrowns.MOD_ID + ":king"));

    public static final RegistryObject<EntityType<SiegeEngineEntity>> TREBUCHET =
            ENTITIES.register("trebuchet", () -> EntityType.Builder.<SiegeEngineEntity>of(SiegeEngineEntity::new, MobCategory.MISC)
                    .sized(2.0f, 3.0f).build(SteelAndCrowns.MOD_ID + ":trebuchet"));

    public static final RegistryObject<EntityType<SiegeEngineEntity>> BATTERING_RAM =
            ENTITIES.register("battering_ram", () -> EntityType.Builder.<SiegeEngineEntity>of(SiegeEngineEntity::new, MobCategory.MISC)
                    .sized(1.5f, 1.5f).build(SteelAndCrowns.MOD_ID + ":battering_ram"));

    public static final RegistryObject<EntityType<com.steelandcrowns.entity.WagonEntity>> WAGON =
            ENTITIES.register("wagon", () -> EntityType.Builder.of(com.steelandcrowns.entity.WagonEntity::new, MobCategory.CREATURE)
                    .sized(1.2f, 1.6f).build(SteelAndCrowns.MOD_ID + ":wagon"));

    public static final RegistryObject<EntityType<com.steelandcrowns.entity.WagonEntity>> COVERED_WAGON =
            ENTITIES.register("covered_wagon", () -> EntityType.Builder.of(com.steelandcrowns.entity.WagonEntity::new, MobCategory.CREATURE)
                    .sized(1.3f, 2.2f).build(SteelAndCrowns.MOD_ID + ":covered_wagon"));
}
