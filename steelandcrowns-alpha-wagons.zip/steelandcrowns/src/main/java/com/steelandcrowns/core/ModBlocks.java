package com.steelandcrowns.core;

import com.steelandcrowns.SteelAndCrowns;
import com.steelandcrowns.block.BloomeryBlock;
import com.steelandcrowns.block.DestructibleWallBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, SteelAndCrowns.MOD_ID);

    public static final RegistryObject<Block> BLOOMERY = BLOCKS.register("bloomery",
            () -> new BloomeryBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE).strength(3.5f).sound(SoundType.STONE)));

    public static final RegistryObject<Block> TANNING_VAT = BLOCKS.register("tanning_vat",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(2.5f).sound(SoundType.WOOD)));

    public static final RegistryObject<Block> CASTLE_WALL_STONE = BLOCKS.register("castle_wall_stone",
            () -> new DestructibleWallBlock(200, BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE).strength(8.0f, 40.0f).sound(SoundType.STONE)));

    public static final RegistryObject<Block> MARKET_STALL = BLOCKS.register("market_stall",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(2.0f).sound(SoundType.WOOD)));

    public static final RegistryObject<Block> THRONE = BLOCKS.register("throne",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD).strength(4.0f).sound(SoundType.WOOD)));
}
