package com.steelandcrowns.core;

import com.steelandcrowns.SteelAndCrowns;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(ForgeRegistries.CREATIVE_MODE_TABS, SteelAndCrowns.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MEDIEVAL_TAB = TABS.register("medieval",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.steelandcrowns.medieval"))
                    .icon(() -> new ItemStack(ModItems.LONGSWORD.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.LONGSWORD.get());
                        output.accept(ModItems.HALBERD.get());
                        output.accept(ModItems.SPEAR.get());
                        output.accept(ModItems.MACE.get());
                        output.accept(ModItems.HEAVY_CROSSBOW.get());
                        output.accept(ModItems.KITE_SHIELD.get());
                        output.accept(ModItems.BUCKLER.get());
                        output.accept(ModItems.PADDED_CHESTPLATE.get());
                        output.accept(ModItems.CHAINMAIL_HAUBERK.get());
                        output.accept(ModItems.PLATE_CUIRASS.get());
                        output.accept(ModItems.VISORED_HELMET.get());
                        output.accept(ModItems.STEEL_INGOT.get());
                        output.accept(ModItems.TANNED_LEATHER.get());
                        output.accept(ModItems.ROYAL_CHARTER.get());
                        output.accept(ModBlocks.BLOOMERY.get());
                        output.accept(ModBlocks.TANNING_VAT.get());
                        output.accept(ModBlocks.CASTLE_WALL_STONE.get());
                        output.accept(ModBlocks.MARKET_STALL.get());
                        output.accept(ModBlocks.THRONE.get());
                    })
                    .build());
}
